function [p_iter,k,e,index]=CG_CLSPIACurve_LSPIA1(B,B_R,B_Q,P0,q,k1,~,miu,lamda,k,tol1,e,R,index) %根据师兄代码来迭代，CLSPIA里LSPIA迭代部分
% circle = 1;
sigma1=B_R'*lamda;    [n,~]=size(P0);n=n-1;B_t=B_Q';
d = zeros(size(P0));
g = zeros(size(P0));
s = zeros(size(q,2),1);r = zeros(size(q,2),1);
p_iter = P0;
if k==0

error{1} = sqrt(sum((R - B_R*p_iter).^2, 2));
e(1,1) = sum(error{1});
% delta = zeros(size(q));c = zeros(size(q));

% for i = 1:m+1
%     delta(i,:) = q(i,:) - B(i,:)*p_iter;
% end
index = cell(n+1,1);
for i=1:n+1
    index{i} = find(B_Q(:,i)~=0);
end  
end
        C=B*p_iter;
        C_Q=removerows(C,k1);
delta = q-C_Q;
 
for i = 1:n+1
    d(i,:) = B_t(i,index{i})*delta(index{i},:);
end
d=d-sigma1;
% d = B_t*delta;
  v = d;
c = B_Q*v;
% g = B_t*c;
for i = 1:n+1
    g(i,:) = B_t(i,index{i})*c(index{i},:);
end
for i = 1:size(q,2)
    s(i) = d(:,i)'*d(:,i)/(v(:,i)'*g(:,i));
end
p_iter = p_iter + v * diag(s);

k = k+1;
error{k+1} = sqrt(sum((R - B_R*p_iter).^2, 2));
% while abs(e(k,1)/e(1,1)-e(k+1)/e(1,1))>=1e-6

    e(k+1,1) = sum(error{k+1});


while 1
    p_q = B*p_iter;C_Q=removerows(p_q,k1);
    delta = q - C_Q;
    d2 = d;
    for i = 1:n+1
        d(i,:) = B_t(i,index{i})*delta(index{i},:);
    end
    d=d-sigma1;
%     d = B_t*delta;
    for i = 1:size(q,2)
        r(i) = d(:,i)'*d(:,i)/(d2(:,i)'*d2(:,i));
    end
    v = d + v * diag(r);
    c = B_Q*v;
    for i = 1:n+1
        g(i,:) = B_t(i,index{i})*c(index{i},:);
    end
%     g = B_t*c;
    for i = 1:size(q,2)
        s(i) = d(:,i)'*d(:,i)/(v(:,i)'*g(:,i));
    end
    p_iter = p_iter + v * diag(s);
    error{k+2} = sqrt(sum((R - B_R*p_iter).^2, 2));
    e(k+2,1) = sum(error{k+2});
    k = k + 1;
   if norm(d)<tol1
return
   end
end

% circle = circle + 1; 

% format shortG
% disp(sum(shijian)/(circle-1));
% for i = 1:length(error)
%     e(i,1) = sum(error{i});
%     e_max(i,1) = max(error{i});
% end
end