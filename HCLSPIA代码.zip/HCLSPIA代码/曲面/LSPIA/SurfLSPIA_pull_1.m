%拉直LSPIA曲面,结果有很小很小的差距,时间长
function [e,k,p,b]=SurfLSPIA_pull_1(B1,B2,P0,q,n1,n2,iter,tol)
b=kron(B1,B2);%配置矩阵拉直
% 初始化
P1(:,:,1)=P0(:,:,1)';P1(:,:,2)=P0(:,:,2)';P1(:,:,3)=P0(:,:,3)';
p0(:,1)=reshape(P1(:,:,1),[(n1+1)*(n2+1),1]);%初始控制顶点拉直
p0(:,2)=reshape(P1(:,:,2),[(n1+1)*(n2+1),1]);
p0(:,3)=reshape(P1(:,:,3),[(n1+1)*(n2+1),1]);
for k=1:iter
    S_vec=b*p0;%曲面
    delta=q-S_vec;%数据点差向量
e(k)=max(sqrt(sum(delta.^2,2)));%拉直算,不能直接用norm
miu=2/max(sum(b'*b,2));%根据拉直后的矩阵算,与曲线类似
    d=miu*b'*delta;%控制点差向量
    p=p0+d;
%     p1(1,:) = q(1,:);%拉直的应该加上另外两个，总共应该四个
%     p1((n1+1)*(n2+1),:) = q((m1+1)*(m2+1),:);%保持端点不变，对误差有影响
    p0=p;
    if k>=2
       if norm((e(k-1)-e(k))/e(1))<=tol%CGLSPIA文献里的终止条件
          break
       end
    end
end

% plot3(S_vec(:,1),S_vec(:,2),S_vec(:,3));