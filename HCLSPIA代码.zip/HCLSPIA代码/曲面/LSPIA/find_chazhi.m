function [u,v]=find_chazhi(q,x1,~,m2)
% x1=[7,57,89,138];
h=length(x1);
% x=[7,57,89,138];
% q=round(q,6); % 四舍五入，保留6位小数
% q=round(q,7); % 四舍五入，保留7位小数
% q=round(q,8); % 四舍五入，保留8位小数
for i=1:h
x(i)=find(q(:,1)==x1(i));
% y(i)=find(q(:,2)==y1(i));
v(i)=mod(x(i),m2);
u(i)=(x(i)-v(i))/m2+1;
end
end