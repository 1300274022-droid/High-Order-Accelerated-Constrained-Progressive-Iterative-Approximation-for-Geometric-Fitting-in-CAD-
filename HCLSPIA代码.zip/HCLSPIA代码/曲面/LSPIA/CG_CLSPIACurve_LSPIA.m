function [P,k,e]=CG_CLSPIACurve_LSPIA(B,B_R,B_Q,P0,Q,k1,~,miu,lamda,k,tol1,e,R) %CLSPIA里LSPIA迭代部分
    sigma1=B_R'*lamda;
    [n,dimension]=size(P0);
d1=(0);v1=zeros(n,dimension);
j=0;
    if k==0
    C1=B_R*P0;delta=R-C1;
e(k+1)=SumErrorCurve_CLSPIA(delta);%LSPIA文献误差，插值误差
    end
while 1
% l=3;
% for l1=1:l

%         C=B*P0;
%         C_Q=removerows(C,k1);
C_Q=B_Q*P0;
    delta1=Q-C_Q;
    epsion1=B_Q'*delta1;
    d2=d1;
    d1=epsion1-sigma1/2;
    r=CG_CLSPIA_weight1(d1,d2,j,dimension);
%     diag([r(:)])
    v1=d1+v1*diag([r(:)]);
    C1=B_Q*v1;
g=B_Q'*C1;
s=CG_CLSPIA_weight(d1,v1,g,dimension);
P=P0+v1*diag([s(:)]); %得到迭代后的所选取部分的控制顶点
C1=B_R*P;delta=R-C1;
k=k+1;
e(k+1)=SumErrorCurve_CLSPIA(delta);%LSPIA文献误差，插值误差
P0=P;
j=j+1;
   if sqrt(sum(power(d1(:), 2)))<tol1
%    if norm((e(k)-e(k+1))/e(1))<tol1
return
   end

end

end