%未扩充的
function DrawBsplineSurf_test(P,Q,Node1,Node2,t1,t2,m,n)
% [S0,~,~]=Bspline_surf(Q,m,n,3,1000,1000,Node1,Node2,t1(1):t1(end)/1000:t1(end),t2(1):t2(end)/1000:t2(end));
% h1=mesh(S0(:,:,1),S0(:,:,2),S0(:,:,3));hold on%初始曲面
%% 
[S1,~,~]=Bspline_surf(P,m,n,3,1000,1000,Node1,Node2,t1(1):t1(end)/1000:t1(end),t2(1):t2(end)/1000:t2(end));
h3=plot3(Q(:,:,1),Q(:,:,2),Q(:,:,3),'b.','MarkerSize',5);
hold on
h1=surf(S1(:,:,1),S1(:,:,2),S1(:,:,3));hold on

% h2=plot3(Q(:,:,1),Q(:,:,2),Q(:,:,3),'r.');hold on%人体,耳朵和牙齿用
% h2=plot3(Q(:,:,1),Q(:,:,2),Q(:,:,3),'r.','MarkerSize',8);hold on%参数曲面用
%% 调光
 shading flat
light('position',[-0.5,-0.5,0.6],'style','infinite','color','w')  %灯光
light('position',[0.5,0.5,0.6],'style','infinite','color','w')
colormap([0,0.8,0.8])
shading interp;shading flat;lighting flat
%% 平均坐标轴
axis equal %平均坐标轴
%% 自己调试数据
% zdir=[1 1 0];
% rotate(h1,zdir,20);

% if ~isempty(R)
%     rotate(h4,zdir,20);
% end
% if ~isempty(Q)
%     rotate(h3,zdir,20);
% end
% 
% view([-2.940992551495013e+02,57.168143967472126])%zahnsimplified


% zdir=[1 0 0];
% rotate(h1,zdir,180);
% 
% if ~isempty(Q)
%     rotate(h3,zdir,180);
% end
% 
% view([-1.080493781018029e+02,-26.911682073032281])%ear
% view(-55.243647185841375,-23.373363594685593);%ear
% view(-37.739780126178232,4.0345801105272);%人脸
% view(-32.570840826792832,4.03759923840996) % peaks(50)
zdir=[1 0 0];
rotate(h1,zdir,90);
% rotate(h2,zdir,90);
if ~isempty(Q)
    rotate(h3,zdir,90);
end
view([-96.539985866848667,-77.3999989359382])

%% 消除白边
set(gca, 'LooseInset', [0,0,0,0]);
%% 消除坐标轴
% set(gca,'xtick',[],'xticklabel',[]);
% set(gca,'ytick',[],'yticklabel',[]);
% set(gca,'ztick',[],'zticklabel',[]);
end