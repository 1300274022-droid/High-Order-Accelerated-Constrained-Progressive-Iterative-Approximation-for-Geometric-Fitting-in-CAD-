function [m2]=shujudian_chapingjunzhi1(m,n1,n2)%n1,n2代表矩阵的行和列
N=length(m);
j=1;a=zeros(1,N);
b=zeros(1,N);
for i=1:N-1    
    a(j)=m(i)+(m(i+1)-m(i))/3;
    b(j)=m(i)+(m(i+1)-m(i))*2/3;
    j=j+1;
end
    m2=[m;a;b];
    m2=reshape(m2,1,N+length(a)+length(b));
    m2=m2(1:length(m2)-2);
    m2=m2';
    h_1=0;
    for i=1:n1
        h(i)=((n2+1)+n2*2+1)+h_1;
        h1(i)=((n2+1)+n2*2+2)*i;
        h_1=h_1+((n2+1)+n2*2+2);
    end
        m2=removerows(m2,[h,h1]);
end