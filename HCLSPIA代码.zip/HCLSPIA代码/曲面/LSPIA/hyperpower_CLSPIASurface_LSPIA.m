function [P,k]=hyperpower_CLSPIASurface_LSPIA(B,B_R,B_Q,P0,Q,k1,~,miu,lamda,k,W,B1) %CLSPIA里LSPIA迭代部分
    sigma1=B_R'*lamda;
    [m,n]=size(W);
    I=eye(m,n);
while 1
    W=W*(2*I-B1*W);
        C=B*P0;
        C_Q=removerows(C,k1);
    delta1=Q-C_Q;
    epsion1=W*B_Q'*delta1;
    d=epsion1-miu*sigma1;
P=P0+d;
P0=P;
k=k+1;
   if norm(d)<1e-2
return
   end

end

end