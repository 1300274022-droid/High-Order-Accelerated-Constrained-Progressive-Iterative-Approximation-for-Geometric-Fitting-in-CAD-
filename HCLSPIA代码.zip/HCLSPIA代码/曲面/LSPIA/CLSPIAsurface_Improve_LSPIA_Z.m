function Z=CLSPIAsurface_Improve_LSPIA_Z(m,s,Z0,B)
A=nchoosek(s,1)*eye(m);
for l=2:s
A=A+(-1)^(l-1)*nchoosek(s,l)*(Z0*B)^(l-1);
end
Z=A*Z0;
end