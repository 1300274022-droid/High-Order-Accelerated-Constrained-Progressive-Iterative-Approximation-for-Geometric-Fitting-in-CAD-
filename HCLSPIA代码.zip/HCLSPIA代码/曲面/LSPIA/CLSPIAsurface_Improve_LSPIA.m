function [P,k]=CLSPIAsurface_Improve_LSPIA(B,B_R,B_Q,P0,Q,k1,tol,miu,lamda,k) %CLSPIA里LSPIA迭代部分

    sigma1=B_R'*lamda;
    Z=miu*B_Q';[m,~]=size(Z);
    s=3;
while 1
        C=B*P0;
        C_Q=removerows(C,k1);
    delta1=Q-C_Q;
    epsion1=Z*delta1;
    d=epsion1-miu*sigma1;
P=P0+d;
P0=P;
Z=CLSPIAsurface_Improve_LSPIA_Z(m,s,Z,B_Q);
k=k+1;
   if norm(d)<1e-6
return
   end

end

end