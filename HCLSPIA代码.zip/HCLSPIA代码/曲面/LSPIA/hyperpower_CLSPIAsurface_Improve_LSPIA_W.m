function W=hyperpower_CLSPIAsurface_Improve_LSPIA_W(I,B1,W)
W=W*(2*I-B1*W);
end