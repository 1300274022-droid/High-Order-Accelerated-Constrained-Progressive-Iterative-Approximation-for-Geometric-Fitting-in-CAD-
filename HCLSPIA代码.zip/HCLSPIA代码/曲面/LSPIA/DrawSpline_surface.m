function DrawSpline_surface(P1,Nik1,Nik2,R)%q是初始顶点，P1是迭代扩充后的顶点，n为控制顶点个数

% plot(R(:,1), R(:,2),...
%                     '*','LineWidth',1,...
%                     'MarkerEdgeColor','r',...
%                     'MarkerFaceColor','r',...
%                     'MarkerSize',4.5);
% axis equal
% % line(q(:,1), q(:,2),'Color',[0 0 0]);
% hold on
% plot(q(:,1), q(:,2),...
%                     'o','LineWidth',1,...
%                     'MarkerEdgeColor','b',...
%                     'MarkerFaceColor','b',...
%                     'MarkerSize',1.5);

% S=b*P1;%曲面
% scatter3(R(:,1),R(:,2),R(:,3), 'filled','r');
plot3(R(:,1),R(:,2),R(:,3),'r.','MarkerSize',7);
hold on

S(:,:,1)=Nik1*P1(:,:,1)*Nik2';
S(:,:,2)=Nik1*P1(:,:,2)*Nik2';
S(:,:,3)=Nik1*P1(:,:,3)*Nik2';

% d1=norm(Q(:,:,1)-S(:,:,1));%查查误差看哪里有问题
% d2=norm(Q(:,:,2)-S(:,:,2));
% d3=norm(Q(:,:,3)-S(:,:,3));

surf(S(:,:,1),S(:,:,2),S(:,:,3))
% axis equal
 shading flat
light('position',[-0.5,-0.5,0.6],'style','infinite','color','w')  %灯光
light('position',[0.5,0.5,0.6],'style','infinite','color','w')
colormap([0,0.8,0.8]);
% view(49.433578124529944,24.232924157693262)% zahnsimplified
view(-65.420564583698905,-63.280157836574695)% ear-cut-21
% view(-32.570840826792832,4.03759923840996) % peaks(50)
%% 绘制局部放大图
% axes('Position',[0.2,0.5,0.3,0.3]);   % 小图 设置小图的大小和位置（左上角位置+宽高）
% plot(S(:,1),S(:,2),'r','LineWidth',1);
% axis equal
% xlim([1,1.2]); %设置放大图坐标范围
end