function [e,e2,k,s,k_lspia,P,shijian]=CLSPIA_surface1(B,B_R,B_Q,K,P0,Q,R,l,k1,tol,n1,n2,tol1) %Q是待逼近点，R是待插值点
s=0; %开始记录LSPIA迭代次数
k_lspia=0;
[~,k2]=size(k1); %获取插值点个数
lamda=zeros(k2,3);
 h=1;
%  e(h)=SumErrorCurve(R-B_R*P0)/(k2+1);
%  h=h+1;
   miu = 2/max(sum(2*B_Q'*B_Q,2));% miu参照的是LSPIA论文选取
%    A1=B_Q'*B_Q;
%    eigenvalues11=eig(2*A1);
%    miu = 2/(max(eigenvalues11)+min(eigenvalues11));% miu参照的是LSPIA论文选取

%    miu2=2/norm(B'*B,inf);%miu=2/norm(B'*B,inf); 是改进LSPIA论文里的

%    miu1=2/max(sum(B_R*inv(2*B_Q'*B_Q)*B_R',2));
%    eigenvalues1 = max(eig(B_R*inv(2*B_Q'*B_Q)*B_R')); %检验miu是否满足，以及谱半径a是否介于-1到1之间

     miu1=2/max(sum((B_R/B_Q)*(B_R/B_Q)'/2,2));

% eigenvalues12=eig(B_R/(2*B_Q'*B_Q)*B_R');
%    miu1=2/(max(eigenvalues12)+min(eigenvalues12));

%    eigenvalues1 = max(eig(B_R/(2*B_Q'*B_Q)*B_R')); %检验miu是否满足，以及谱半径a是否介于-1到1之间
% miu12=2/eigenvalues1;

   time=0;
   shijian=0;
      e2=0;%准备计算每次LSPIA的误差
   %% 数据准备
P1(:,:,1)=P0(:,:,1)';P1(:,:,2)=P0(:,:,2)';P1(:,:,3)=P0(:,:,3)';
p0(:,1)=reshape(P1(:,:,1),[(n1+1)*(n2+1),1]);%初始控制顶点拉直
p0(:,2)=reshape(P1(:,:,2),[(n1+1)*(n2+1),1]);
p0(:,3)=reshape(P1(:,:,3),[(n1+1)*(n2+1),1]);
   %% 计算第一次Z值
%            if s==0
%             Z(:,:,s+1)=miu*B_Q';
%                 [m,~]=size(Z);
%            end
           %% 计算第一次W值
               B1=B_Q'*B_Q;
    B2=B1^2;
    miu3 = 2/max(sum(B2,2));% miu参照的是LSPIA论文选取
    W=miu3*B1;

%                B1=B'*B;
%     B2=B1^2;
%     miu3 = 2/max(sum(B2,2));% miu参照的是LSPIA论文选取
%     W(:,:,1)=miu3*B1;
    %% UZAWA迭代
if l==0
    P=p0;
        C1=B_R*P;C2=B*P;
       delta=R-C1;delta2=K-C2;
%           e(h)=SumErrorCurve(delta)/(k2+1);%LSPIA文献误差，平均误差
       e(h)=SumErrorCurve_CLSPIA(delta);%LSPIA文献误差，插值误差
       e1(h)=SumErrorCurve_CLSPIA(delta2);%LSPIA文献误差，数据点误差
       k=0;
else
    index=(0);
tic
for k=1:l
    t1=clock;
%   [P,s,e2]=CLSPIASurface_LSPIA(B,B_R,B_Q,p0,Q,k1,tol,miu,lamda,s,tol1,e2,R); %普通CLSPIA算法
%  [P,s]=CLSPIAsurface_Improve_LSPIA(B,B_R,B_Q,p0,Q,k1,tol,miu,lamda,s); %改进CLSPIA算法
%  [P,s,Z]=CLSPIAsurface_Improve_LSPIA1(B,B_R,B_Q,p0,Q,k1,tol,miu,lamda,s,m,Z); %改进CLSPIA算法，在此基础上存储Z值，避免重复计算
% [P,s]=hyperpower_CLSPIASurface_LSPIA(B,B_R,B_Q,p0,Q,k1,tol,miu,lamda,s,W,B1); %hyperpower_CLSPIA算法
%  [P,s,W]=hyperpower_CLSPIAsurface_Improve_LSPIA(B,B_R,B_Q,p0,Q,k1,miu,lamda,s,W,B1); %储存W
[P,s,e2]=CG_CLSPIACurve_LSPIA(B,B_R,B_Q,p0,Q,k1,tol,miu,lamda,s,tol1,e2,R);
% [P,s,e2,index]=CG_CLSPIACurve_LSPIA1(B,B_R,B_Q,p0,Q,k1,tol,miu,lamda,s,tol1,e2,R,index);%师兄的，挑选下标，不用这样直接乘就行

k_lspia(k)=s-sum(k_lspia);
 t2=clock;time=time+etime(t2,t1);
    p0=P;
    C1=B_R*P;C2=B*P;
       delta=R-C1;delta2=K-C2;
%           e(h)=SumErrorCurve(delta)/(k2+1);%LSPIA文献误差，平均误差
       e(h)=SumErrorCurve_CLSPIA(delta);%LSPIA文献误差，插值误差
       e1(h)=SumErrorCurve_CLSPIA(delta2);%LSPIA文献误差，数据点误差
       lamda=lamda+(C1-R)*miu1;
       %终止条件
%     if h>=2
       if e(end)<=tol
          break
       end
%     end
              h=h+1;
end
toc
% shijian=toc;
end
fprintf('e=%.4e',e(end));
fprintf('e1=%.4e',e1(end));
fprintf('LSPIA部分的迭代时间是:%f',time);
end