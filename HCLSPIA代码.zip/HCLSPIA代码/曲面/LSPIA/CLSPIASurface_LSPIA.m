function [P,k,e]=CLSPIASurface_LSPIA(B,B_R,B_Q,P0,Q,k1,~,miu,lamda,k,tol1,e,R) %CLSPIA里LSPIA迭代部分
    sigma1=B_R'*lamda;
    if k==0
    C1=B_R*P0;delta=R-C1;
e(k+1)=SumErrorCurve_CLSPIA(delta);%LSPIA文献误差，插值误差
    end
while 1
%         C=B*P0;
%         C_Q=removerows(C,k1);
C_Q=B_Q*P0;
    delta1=Q-C_Q;
    epsion1=B_Q'*delta1;
    d=miu*(2*epsion1-sigma1);
P=P0+d;
C1=B_R*P;delta=R-C1;
k=k+1;
e(k+1)=SumErrorCurve_CLSPIA(delta);%LSPIA文献误差，插值误差
P0=P;
   if sqrt(sum(power(d(:), 2)))<tol1
return
   end

end

end