function [P,k,Z]=CLSPIAsurface_Improve_LSPIA1(B,B_R,B_Q,P0,Q,k1,tol,miu,lamda,k,m,Z) %CLSPIA里LSPIA迭代部分
% 对该算法进行改进，存储了Z值，避免了重复运算
   
sigma1=B_R'*lamda;
    s=3;
    %% 完成第一次LSPIA循环迭代，存储Z值
        if k==0
while 1
        C=B*P0;
        C_Q=removerows(C,k1);
    delta1=Q-C_Q;
    epsion1=Z(:,:,k+1)*delta1;
    d=epsion1-miu*sigma1;
P=P0+d;
P0=P;
k=k+1;
Z(:,:,k+1)=CLSPIAsurface_Improve_LSPIA_Z(m,s,Z(:,:,k),B_Q);
   if norm(d)<1e-6
return
   end

end

        end
                [~,~,k3]=size(Z);
        %% 进行第二轮以上的LSPIA迭代
%     if k2>k3
%         Z(:,:,k2)=CLSPIACurve_Improve_LSPIA_Z(m,s,Z(:,:,k2-1),B_Q);
%     end
        if k>0
            k2=1; %记录该使用Z(k2)
while 1
        C=B*P0;
        C_Q=removerows(C,k1);
    delta1=Q-C_Q;
        if k2>k3
        Z(:,:,k2)=CLSPIACurve_Improve_LSPIA_Z(m,s,Z(:,:,k2-1),B_Q);
        end
    epsion1=Z(:,:,k2)*delta1;
    d=epsion1-miu*sigma1;
P=P0+d;
P0=P;
k=k+1;
k2=k2+1;
   if norm(d)<1e-6
return
   end

end

        end
end