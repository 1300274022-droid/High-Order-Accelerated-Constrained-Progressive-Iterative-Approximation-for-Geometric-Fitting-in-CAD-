function [A_q,B_r,B,r1]=CLSPIA_surface_AB(B1,B2,m1,m2,n1,n2,u_r,v_r)
% tu=linspace(1,m1+1,m1+1);tv=linspace(1,m2+1,m2+1);
% k1=1;
% for k=1:length(u_r)
% for i1=1:(m1+1)
%     for j1=1:(m2+1)
%         if i1~=u_r(k) && j1~=v_r(k)
%             u_q(k)=tu(i1);v_q(k)=tv(j1);
%             k1=k1+1;
%         end
%     end
% end
% end
B=kron(B1,B2);
for i=1:length(u_r)
r1(i)=(u_r(i)-1)*(m2+1)+v_r(i); %竖着拉直
end
q=1:(m1+1)*(m2+1);

keep_indices = true(size(q));
for i = 1:numel(r1)
    keep_indices(q == r1(i)) = false;
end

% 使用逻辑索引来获取保留的元素
q1= q(keep_indices);

%尝试生成j/(n2+1)的商和余数，结果和叉乘列全取一样
% for j=0:(n1+1)*(n2+1)-1
%   k1(j+1)=floor(j/(n2+1))+1;k2(j+1)=rem(j,n2+1)+1;
% end
%% 可以试试用remove来做
B_r=B(r1,:);
A_q=B(q1,:);

%% 以下是尝试用for循环做的AB，第一版，有问题
% for i=1:length(u_r)
%     for j=1:(n1+1)*(n2+1)
%         if j==(n1+1)*(n2+1)
%             B(i,j)=B1(u_r(i),floor(j/(n2+1)))*B2(v_r(i),rem(j,(n2+1))+1);
%     else
%         B(i,j)=B1(u_r(i),floor(j/(n2+1))+1)*B2(v_r(i),rem(j,(n2+1))+1);
%         end
%     end
% end
% h=(m1+1)*(m2+1)-length(u_r);k=1;k1=1;
% 
% for i2=1:(m1+1)*(m2+1)-length(u_r)
%     for j2=1:(n1+1)*(n2+1)
%         if i2~=u_r(k) && j2~=v_r(k)
%             if j2==(n1+1)*(n2+1)
%         A(i2,j2)=B1(ceil((i2+k1-1)/(m2+1)),floor(j2/(n2+1)))*B2(ceil(j2/(m1+1)),rem(j2,(n2+1))+1);
%             else
% %                 ceil((i2+k1-1)/(m2+1))
%         A(i2,j2)=B1(ceil((i2+k1-1)/(m2+1)),floor(j2/(n2+1))+1)*B2(ceil(j2/(m1+1)),rem(j2,(n2+1))+1);
%             end
%         else
%             k=k+1;k1=k1+1;
%             if k>length(u_r)
%                 k=length(u_r);
%             end
%         end
%     end
% end

end