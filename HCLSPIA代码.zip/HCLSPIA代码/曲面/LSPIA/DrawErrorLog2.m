function DrawErrorLog2(e1,e5,e2,e3,e4,l,Xscale,Xtick)
figure
plot(e1,'r.-','MarkerIndices',1:Xscale:length(e1));hold on
plot(e5,'.-','Color',[0 0 0],'MarkerIndices',1:Xscale:length(e5));hold on
plot(e2,'b.-','MarkerIndices',1:Xscale:length(e2));hold on
plot(e3,'.-','Color',[0.85 0.325 0.098],'MarkerIndices',1:Xscale:length(e3));hold on
plot(e4,'m.-','MarkerIndices',1:Xscale:length(e4));hold on
legend('CLSPIA','CG-CLSPIA','s=2','s=3','s=4')
xlabel('Number of iterations')%改成k+2?
% xlabel('迭代次数')%改成k+2?
ylabel('log(Ek/E0)')

%% y轴取对数
set(gca,'YScale','log');%y轴取对数
%% 取消科学计数法
ax = gca;
ax.XAxis.Exponent = 0;%常数2为指数值，改为0即不使用科学计数法
%% 消除白边
set(gca, 'LooseInset', [0,0,0,0]);
%% 通过BaseZoom函数进行局部放大
zp=BaseZoom();
zp.plot;

%% 图窗设置，编辑-坐标区属性
% set(gca,'XTick',[0:Xtick:l-1]);%iter 151
% set(gca,'YTick',[0,1]);%设置xy轴刻度
% set(gcf,'Position',[500,330,550,440]);%控制图窗大小，前两个参数表示在显示器中的起始坐标，后两个表示图像窗口的长和宽，默认单位是像素！
% ylim([1e-15,10]);%限制y坐标轴的开始和结束位置
% xlabel('迭代次数')
% ylabel('误差对数')%取对数
% legend('CLSPIA')
% legend('PIA','JacobiPIA','WPIA','GSPIA','alg1PIA')
% title('例  ')
end