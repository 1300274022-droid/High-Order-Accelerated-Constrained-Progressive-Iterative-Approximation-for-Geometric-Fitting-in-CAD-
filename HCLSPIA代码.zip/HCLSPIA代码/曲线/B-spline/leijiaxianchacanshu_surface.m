function t=leijiaxianchacanshu_surface(n,px,py,pz)
t(1)=0; t(n+1)=1;L=0;q=(0);qx=(0);qy=(0);qz=(0);
    for i=1:n
    qx(i)=px(i+1)-px(i);
    qy(i)=py(i+1)-py(i);
    qz(i)=pz(i+1)-pz(i);
    q(i)=sqrt(qx(i)^2+qy(i)^2+qz(i)^2);
    L=L+q(i);
    end
for i=1:n-1
    t(i+1)=t(i)+q(i)/L;

end
end