function NodeVector=chazhijiedian2(n) %n是下标
u=linspace(0,1,n+1);
NodeVector=(0);u_1=(0);
for p=1:n-3
        u_1(p)=(u(p+1)+u(p+2)+u(p+3))/3;
end
for i=1:4
    NodeVector(i)=u(1);
end
for i=5:n+1
    NodeVector(i)=u_1(i-4);
end
for i=n+2:n+5
    NodeVector(i)=u(n+1);
end
end