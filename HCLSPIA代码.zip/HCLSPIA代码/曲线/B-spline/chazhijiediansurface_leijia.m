function u1=chazhijiediansurface_leijia(m,n,px,py,pz,flag)%m,n为控制点个数-1

if flag==1
    u=zeros(m+1,n+1);
for i=0:m
u(i+1,:)=leijiaxianchacanshu_surface(n,px(i+1,:),py(i+1,:),pz(i+1,:));
end
u1=sum(u)/(m+1);
end

if flag==2
    v=zeros(n+1,m+1);
for j=0:n
v(j+1,:)=leijiaxianchacanshu_surface(m,px(:,j+1)',py(:,j+1)',pz(:,j+1)');
end
u1=sum(v)/(n+1);
end

% if flag==1
% for i=1:m
%     for j=1:n-1
%         q1x=px(i,j)-px(i,j+1);q1y=py(i,j)-py(i,j+1);q1z=pz(i,j)-pz(i,j+1);
%         u(i,j)=sqrt(q1x^2+q1y^2+q1z^2);
%     end
% end
% for i=1:m
%     for j=1:n-1
%         q2(i,j)=sum(u(i,1:j))/sum(u(i,:));
%     end
% end
% u1=mean(q2,1);u1=[0 u1];
% end
% 
% if flag==2
% for j=1:m
%     for i=1:n-1
%         q1x=px(i,j)-px(i+1,j);q1y=py(i,j)-py(i+1,j);q1z=pz(i,j)-pz(i+1,j);
%         u(i,j)=sqrt(q1x^2+q1y^2+q1z^2);
%     end
% end
% for j=1:m
%     for i=1:n-1
%         q2(i,j)=sum(u(1:i,j))/sum(u(:,j));
%     end
% end
% u1=mean(q2,2)';u1=[0 u1];
% end

end