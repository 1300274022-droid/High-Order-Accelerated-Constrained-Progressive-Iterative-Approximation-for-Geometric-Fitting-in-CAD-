function LPIA_Bspline_cube(n,k,l,p,adjust)%使用0到n+1这篇论文算法
q=p;

% T1=leijiaxianchacanshu(n,p,2);

%% 构建配置矩阵
   NodeVector=chazhijiedian2(n);
   T1=linspace(0,1,n+1);
   P1=p;
   Nik=spcol(NodeVector, k+1, T1);%配置矩阵
%% LPIA
   for j=0:l
    P0=Nik*P1;
    E=zeros(n+1,3);
    E(adjust,:)=q(adjust,:)-P0(adjust,:);
    e(j+1)=SumError(E);
    P1=P1+E;
   end
%% 计算迭代时间
% tic
% e1=sqrt(step_x1(:,l+1).^2+step_y1(:,l+1).^2);%最后一次拟合误差
%  e=sum(e1,1);
% while e>0.1^12
%     l=l+1;
%        for t=1:n
%     for i = 0:n+1 
%       Bt_x1(i+1) = P1(i+1,1)*Nik(t,i+1); 
%       Bt_y1(i+1) = P1(i+1,2)*Nik(t,i+1); 
%     end
%     Bt_x2(t,j+1) = sum(Bt_x1); 
%     Bt_y2(t,j+1) = sum(Bt_y1);  
%        end
%        for i=1:length_adjust
%          h_1=adjust(i);
%     step_x(h_1,j+1)=q(h_1,1)-Bt_x2(h_1,j+1);
%     step_y(h_1,j+1)=q(h_1,2)-Bt_y2(h_1,j+1);
%     step_x1(i) = step_x(h_1,j+1);%为拟合误差计算准备
%     step_y1(i) = step_y(h_1,j+1);
%     P1(h_1+1,1)=P1(h_1+1,1)+step_x(h_1,j+1);
%     P1(h_1+1,2)=P1(h_1+1,2)+step_y(h_1,j+1);
%        end
%  e1=sqrt(step_x1.^2+step_y1.^2);%最后一次拟合误差
%  e=sum(e1,1);
%     P1(1,:)=P1(2,:);
%     P1(n+2,:)=P1(n+1,:);
%  end
% toc
% fprintf('l=%f',l);

   %% 输出拟合误差e
%     e1=sqrt(step_x1(:,l+1).^2+step_y1(:,l+1).^2);%最后一次拟合误差
   fprintf('e=%e',e);

%% 绘制迭代次数与迭代误差折线图
%      x=0:l;
%      plot(x,e,'-*k');
% %      legend('PIA');
%      hold on

  P=P1';
  P2=q';
  DrawSpline_cube1(n,k,P,P2,NodeVector);
  for i=1:length(adjust)
      plot3(P2(1, adjust(i)), P2(2, adjust(i)),P2(3,adjust(i)),...
                    'o','LineWidth',1,...
                    'MarkerEdgeColor','k',...
                    'MarkerFaceColor','r',...
                    'MarkerSize',6);
hold on
  end

end