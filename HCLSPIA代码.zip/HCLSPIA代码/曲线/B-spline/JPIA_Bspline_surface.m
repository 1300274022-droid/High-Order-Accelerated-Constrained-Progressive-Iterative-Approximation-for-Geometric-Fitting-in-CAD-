function [e,h,p]=JPIA_Bspline_surface(m,n,k,l,p,Error)
%% 设计参数以及节点向量
q=p;
[T1,T2]=Parameter_jacobi(p,m,n);
[B1,B2]=jaboci_Matrix(m,n,k,T1,T2);
 D1=diag(diag(B1));  D2=diag(diag(B2));  
 D_1=inv(D1);D_2=inv(D2);
w=2/(max(eig(B1/D1))*max(eig(B2/D2))+min(eig(B1/D1))*min(eig(B2/D2)));

%% 开始迭代
tic
  for h=0:l
S(:,:,1) = B1*p(:,:,1)*B2';
S(:,:,2) = B1*p(:,:,2)*B2';
S(:,:,3) = B1*p(:,:,3)*B2';
delta=q-S;delta_x=delta(:,:,1);delta_y=delta(:,:,2);delta_z=delta(:,:,3);
e(h+1)=MaxSurfaceError(delta_x,delta_y,delta_z);
delta(:,:,1)=w*D_1*delta_x*(D_2');
delta(:,:,2)=w*D_1*delta_y*(D_2');
delta(:,:,3)=w*D_1*delta_z*(D_2');
p=p+delta;
if e(h+1)<Error %到达一定误差跳出
    break
end
  end
  toc
%% 计算迭代次数和时间
% tic
%      while e>0.1^10
%          l=l+1;
% S(:,:,1) = B1*p(:,:,1)*B2';
% S(:,:,2) = B1*p(:,:,2)*B2';
% S(:,:,3) = B1*p(:,:,3)*B2';
% delta=q-S;delta_x=delta(:,:,1);delta_y=delta(:,:,2);delta_z=delta(:,:,3);
% e(h+1)=MaxSurfaceError(delta_x,delta_y,delta_z);
% delta(:,:,1)=w*D_1*delta_x*(D_2');
% delta(:,:,2)=w*D_1*delta_y*(D_2');
% delta(:,:,3)=w*D_1*delta_z*(D_2');
%      end
%  toc
% %  disp(['运行时间: ',num2str(toc)]);
%      fprintf('l=%f',l);


   %% 输出拟合误差e
%    e1(1)=e(1);e1(2)=e(4);e1(3)=e(6);e1(4)=e(11);e1(5)=e(21);
%    fprintf('e=%e',e1);
%      fprintf('e=%e',e);
%% 绘制迭代次数与迭代误差折线图
%      x=0:l;
%      plot(x,e,'-*k');
% %      legend('PIA');
%      hold on

%% 绘图
% DrawSplinesurface(m-1,n-1,k,k,p,q);
% title('JPIA');
end