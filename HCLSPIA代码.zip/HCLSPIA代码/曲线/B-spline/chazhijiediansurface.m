function NodeVector=chazhijiediansurface(n,p,dimension)
q=zeros(n-1,dimension);
NodeVector=zeros(1,n+6);
for i=0:3
    NodeVector(i+1)=0;
end
for i=4:n+2
    for j=2:i-2
        q(j-1,:)=p(j,:)-p(j-1,:);
        NodeVector(i+1)=NodeVector(i+1)+norm(q(j-1,:));
    end
end
for i=n+3:n+5
    NodeVector(i+1)=NodeVector(n+3);
end
end