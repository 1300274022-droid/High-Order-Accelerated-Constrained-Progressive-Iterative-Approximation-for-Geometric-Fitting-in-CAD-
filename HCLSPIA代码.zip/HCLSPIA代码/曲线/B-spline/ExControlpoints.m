%�������ݵ�
function [Q0]=ExControlpoints(Q,m,n)%m,nΪ���ƶ������-1
Q0 = zeros();
for i=1:3
    Q0(1,2:n+2,i) = Q(1,:,i);
    Q0(2:m+2,1,i) = Q(:,1,i);
    Q0(1,1,i) = Q(1,1,i);
    Q0(1,n+3,i) = Q(1,n+1,i);
    Q0(m+3,1,i) = Q(m+1,1,i);
    Q0(2:m+2,n+3,i) = Q(:,n+1,i);
    Q0(m+3,2:n+2,i) = Q(m+1,:,i);
    Q0(m+3,n+3,i) = Q(m+1,n+1,i);
    Q0(2:m+2,2:n+2,i) = Q(:,:,i);
end
end