function GSPIA_spline_surface(m,n,k,l,P)%扩充配置矩阵
[T1,T2]=Parameter_jacobi(P,m,n);
NodeVector1=[0 0 0 T1 T1(m) T1(m) T1(m)];NodeVector2=[0 0 0 T2 T2(n) T2(n) T2(n)];
T1=[T1(1) T1 T1(end)];T2=[T1(2) T2 T2(end)];
Nik1=ExpandMatrix(m,k,T1,NodeVector1);Nik2=ExpandMatrix(m,k,T2,NodeVector2);
P=ExControlpoints(P,m-1,n-1);
Q=P;
%% 进行迭代准备
F1=tril(Nik1);G1=-triu(Nik1,1);H1=F1\G1;
F2=tril(Nik2');G2=-triu(Nik2',1);H2=G2/F2;
H11=(0);H22=(0);
    for i=1:10
%         H=vrho(H1^i)
        if vrho(H1^i)<sqrt(3)-1%谱半径
            p1=i;
            break;
        end
    end
    for i=1:10
        if vrho(H2^i)<sqrt(3)-1%谱半径
            q1=i;
            break;
        end
    end
for i=0:p1-1
    H11=H11+H1^i;
end
for i=0:q1-1
    H22=H22+H2^i;
end
M1=H11/F1;M2=F2\H22;
%% 进行GSPIA
 for q=0:l
    S(:,:,1) = Nik1*P(:,:,1)*Nik2';
    S(:,:,2) = Nik1*P(:,:,2)*Nik2';
    S(:,:,3) = Nik1*P(:,:,3)*Nik2';
E=Q-S;
e(q+1)=MaxSurfaceError(E(:,:,1),E(:,:,2),E(:,:,3));
    E1(:,:,1) = M1*E(:,:,1)*M2;%新的差向量
    E1(:,:,2) = M1*E(:,:,2)*M2;
    E1(:,:,3) = M1*E(:,:,3)*M2;
   P=P+E1;
 end
 %% 输出误差
    e1(1)=e(1);e1(2)=e(4);e1(3)=e(6);e1(4)=e(11);e1(5)=e(21);
   fprintf('e=%e',e1);
%     fprintf('e=%e',e);