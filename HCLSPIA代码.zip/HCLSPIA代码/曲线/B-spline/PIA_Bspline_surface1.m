function [e,h,p1]=PIA_Bspline_surface1(m,n,k,l,p,Error)%配置矩阵扩充，不能直接用 A=kron(Nik1,Nik2);
% 绘画控制点曲线,m,n是控制顶点个数
% figure();
% plot3(Px,Py,Pz,'r','linewidth',2);
% hold on
% plot3(Px',Py',Pz','r','linewidth',2);
% hold on
% plot3(Px,Py,Pz,'g.','markersize',20,'linewidth',2);
% hold on
%JPIA论文节点设置
Px1=chazhicontrolpointsurface(m,n,p(:,:,1));
Py1=chazhicontrolpointsurface(m,n,p(:,:,2));
Pz1=chazhicontrolpointsurface(m,n,p(:,:,3));
NodeVector1=chazhijiediansurface1_u(m,n,p(:,:,1),p(:,:,2),p(:,:,3));NodeVector2=chazhijiediansurface1_v(n,m,p(:,:,1),p(:,:,2),p(:,:,3));T1(1:m)=NodeVector1(4:m+3);T2(1:n)=NodeVector2(4:n+3);
p1(:,:,1)=Px1;p1(:,:,2)=Py1;p1(:,:,3)=Pz1;
q=p;
%% 确定配置矩阵
B1=spcol(NodeVector1,k+1,T1);
B2=spcol(NodeVector2,k+1,T2);
%% 进行PIA
tic
 for h=0:l
S(:,:,1) = B1*p1(:,:,1)*B2';
S(:,:,2) = B1*p1(:,:,2)*B2';
S(:,:,3) = B1*p1(:,:,3)*B2';
delta=q-S;
% delta_x=delta(:,:,1);delta_y=delta(:,:,2);delta_z=delta(:,:,3);
e(h+1)=MaxSurfaceError(delta(:,:,1),delta(:,:,2),delta(:,:,3));
delta1=chazhicontrolpointsurface1(m,n,delta);
p1=p1+delta1;
if e(h+1)<Error %到达一定误差跳出
    break
end
 end
 toc
%% 输出拟合误差e
% e1(1)=e(1);e1(2)=e(4);e1(3)=e(6);e1(4)=e(11);e1(5)=e(21);
%    fprintf('e=%e',e1);
%    fprintf('e=%e',e);
%% 绘画图像
% DrawSplinesurface(m+1,n+1,3,3,p1,q)
% title('PIA');
end