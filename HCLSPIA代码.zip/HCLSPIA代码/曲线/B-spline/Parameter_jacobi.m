function [T1,T2]=Parameter_jacobi(Q,m,n) %jacobi论文的参数设定
T1=(0);T2=(0);
T1(1)=0;T2(1)=0;d1=(0);d2=(0);
for i=2:m
for j=1:n
        d1(i,j)=norm(reshape(Q(i,j,:),[1,3])-reshape(Q(i-1,j,:),[1,3]));
       T1(i)=T1(i-1)+sum(d1(i,1:j))/(n+1);
end
end
for j=2:n
for i=1:m
        d2(i,j)=norm(reshape(Q(i,j,:),[1,3])-reshape(Q(i,j-1,:),[1,3]));
        T2(j)=T2(j-1)+sum(d2(1:i,j))/(m+1);
end
end
end