function NodeVector=chazhijiedian1(n)%n为控制点个数-1
NodeVector=(0);
for i=1:4
    NodeVector(i)=0;
end
for i=5:n+3
    NodeVector(i)=i-4;
end
for i=n+4:n+7
    NodeVector(i)=n;
end
end