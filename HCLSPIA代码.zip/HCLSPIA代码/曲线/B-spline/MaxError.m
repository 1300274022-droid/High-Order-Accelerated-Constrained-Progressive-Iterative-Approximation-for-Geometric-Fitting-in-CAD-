function e=MaxError(E)
[row,~]=size(E);
for i=1:row
    d=E(i,:);
    e0(i)=norm(d,2);
end
e=max(e0);
end