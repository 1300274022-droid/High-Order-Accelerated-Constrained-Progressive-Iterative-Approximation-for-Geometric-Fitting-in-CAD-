function PIA_Bspline(n,k,l,p,dimension)%n为控制点个数
q=p;
[Nik,~,NodeVector]=peizhi_Matrix(n,k);%配置矩阵

%% 进行PIA
   for j=0:l
P1=chazhicontrolpoint(n,p,dimension);
E=q-Nik*P1;
e(j+1)=MaxError(E);
p=p+q-Nik*P1;
   end
P1=chazhicontrolpoint(n,p,dimension);%扩充控制顶点

   %% 输出拟合误差e
%     fprintf('e=%e',e);

%绘制迭代次数与迭代误差折线图
%      x=0:l;
%      plot(x,e,'-*k');
% %      legend('PIA');
%      hold on
%% 绘制图像
S=Nik*P1;
plot(S(:,1),S(:,2),'r','LineWidth',1);
hold on
axis equal
% DrawSpline(n, k, q,P1, NodeVector)
% DrawSpline_cube(n,k, q,P1, NodeVector)
end