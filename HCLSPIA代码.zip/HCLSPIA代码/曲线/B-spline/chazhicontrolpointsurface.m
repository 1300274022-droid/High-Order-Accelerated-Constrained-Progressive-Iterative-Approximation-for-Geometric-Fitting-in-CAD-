function P1=chazhicontrolpointsurface(m,n,p)
P1=zeros(m+2,n+2);
P1(2:m+1,2:n+1)=p;
for j=1:n
P1(1,j+1)=P1(2,j+1);
P1(m+2,j+1)=P1(m+1,j+1);
end
for i=1:m
    P1(i+1,1)=P1(i+1,2);
    P1(i+1,n+2)=P1(i+1,n+1);
end
P1(1,1)=P1(2,2);P1(1,n+2)=P1(2,n+1);P1(m+2,n+2)=P1(m+1,n+1);P1(m+2,1)=P1(m+1,2);
end