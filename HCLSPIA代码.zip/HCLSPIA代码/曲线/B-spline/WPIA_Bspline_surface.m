function WPIA_Bspline_surface(m,n,k,l,Px,Py,Pz)
%绘画控制顶点曲线
% figure();
% plot3(Px,Py,Pz,'r','linewidth',2);
% hold on
% plot3(Px',Py',Pz','r','linewidth',2);
% hold on
% plot3(Px,Py,Pz,'g.','markersize',20,'linewidth',2);
% hold on
% NodeVector1=chazhijiedian2(m);NodeVector2=chazhijiedian2(n);T1=linspace(0,1,m+1);T2=linspace(0,1,n+1);
NodeVector1=chazhijiediansurface1_u(m,n,Px,Py,Pz);NodeVector2=chazhijiediansurface1_v(n,m,Px,Py,Pz);T1(1:m)=NodeVector1(4:m+3);T2(1:n)=NodeVector2(4:n+3);
T1=linspace(0,1,m+1);
T2=linspace(0,1,n+1);
%% 初始化控制顶点
P(:,1)=reshape(Px',[],1);P(:,2)=reshape(Py',[],1);P(:,3)=reshape(Pz',[],1);
Q=P;
%% 确定配置矩阵
Nik1=spcol(NodeVector1,k+1,T1);
Nik2=spcol(NodeVector2,k+1,T2);
w=2/(1+min(eig(Nik1))*min(eig(Nik2)));
%% 进行PIA
A=kron(Nik1,Nik2);
 for q=0:l
E=Q-A*P;
e(q+1)=MaxError(E);
   P=P+w*(Q-A*P);
 end
%% 输出拟合误差e
% e=MaxError(E);
e1(1)=e(1);e1(2)=e(4);e1(3)=e(6);e1(4)=e(11);e1(5)=e(21);
   fprintf('e=%e',e1);
%    fprintf('e=%e',e);
%% 绘画图像
% for i=1:m+1
%     for j=1:n+1
%         X(i,j)=P(j+(i-1)*(n+1),1);
%         Y(i,j)=P(j+(i-1)*(n+1),2);
%         Z(i,j)=P(j+(i-1)*(n+1),3);
%     end
% end
% k1=3;l1=3;
% P1(:,:,1)=X;P1(:,:,2)=Y;P1(:,:,3)=Z;
% DrawSplinesurface(m,n,k1,l1,P1)
% title('WPIA');
end