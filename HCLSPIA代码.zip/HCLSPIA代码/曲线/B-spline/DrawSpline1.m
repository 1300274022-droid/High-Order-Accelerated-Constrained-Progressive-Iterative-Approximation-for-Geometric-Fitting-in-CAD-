function DrawSpline1(n, k, q,P1,P,dimension)%q是初始顶点，n为控制顶点个数,P1是控制曲线上的点
%选择节点矢量

% NodeVector=chazhijiedian(n,q,2);
NodeVector=chazhijiedian1(n-1);

if dimension==2
plot(q(:,1), q(:,2),'r.','MarkerSize',5);
hold on
plot(P(:,1), P(:,2),'b.','MarkerSize',5);
P1=chazhicontrolpoint(n,P1,dimension);%将P1进行扩充
P1=P1';
T1=NodeVector(k+1:n+3);
Nik=BaseFunction(n+1,k,T1,NodeVector);
p1=P1 * Nik;
plot(p1(1,:),p1(2,:),'k','LineWidth',1);
axis equal
else
plot3(q(:,1), q(:,2),q(:,3),'r.','MarkerSize',5);
hold on
plot3(P(:,1), P(:,2),P(:,3),'b.','MarkerSize',5);
P1=chazhicontrolpoint(n,P1,dimension);%将P1进行扩充
P1=P1';
T1=NodeVector(k+1:n+3);
Nik=BaseFunction(n+1,k,T1,NodeVector);
p1=P1 * Nik;
plot3(p1(1,:),p1(2,:),p1(3,:),'k','LineWidth',1);
axis equal
end