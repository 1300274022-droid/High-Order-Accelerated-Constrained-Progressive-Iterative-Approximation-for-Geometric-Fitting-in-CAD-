function [B1,B2]=jaboci_Matrix(m,n,k,T1,T2)%采用jacobi一文的配置矩阵
NodeVector1=[0 0 0 T1 T1(m) T1(m) T1(m)];NodeVector2=[0 0 0 T2 T2(n) T2(n) T2(n)];
Nik=spcol(NodeVector1,k+1,T1);Nik_1=spcol(NodeVector2,k+1,T2);

    B1=zeros(m);B2=zeros(n);
    B1(1,1)=1;B1(m,m)=1;B2(1,1)=1;B2(n,n)=1;
    B1(2:m-1,:)=Nik(2:m-1,2:m+1);B2(2:n-1,:) = Nik_1(2:n-1,2:n+1);
end