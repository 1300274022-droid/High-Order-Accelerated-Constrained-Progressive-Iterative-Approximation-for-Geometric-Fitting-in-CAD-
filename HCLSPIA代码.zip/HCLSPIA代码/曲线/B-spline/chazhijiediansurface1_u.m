function NodeVector=chazhijiediansurface1_u(m,n,px,py,pz)
NodeVector=zeros(1,m+6);
for i=0:3
    NodeVector(i+1)=0;
end
for i=4:m+2
    q=0;
    for j=1:n
        qx=px(i-2,j)-px(i-3,j);
        qy=py(i-2,j)-py(i-3,j);
        qz=pz(i-2,j)-pz(i-3,j);
        q=q+sqrt(qx^2+qy^2+qz^2);
    end
    NodeVector(i+1)=NodeVector(i)+q/n;
end
for i=m+3:m+5
    NodeVector(i+1)=NodeVector(m+3);
end
end