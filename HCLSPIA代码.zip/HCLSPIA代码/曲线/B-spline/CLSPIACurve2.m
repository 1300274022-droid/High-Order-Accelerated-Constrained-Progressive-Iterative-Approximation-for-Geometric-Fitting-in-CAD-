function [e,e2,k,s,k_lspia,P,shijian]=CLSPIACurve2(B,B_R,B_Q,K,P0,Q,R,l,k1,tol,tol1,m) %Q是待逼近点，R是待插值点
s=0; %开始记录LSPIA迭代次数
shijian=0;%用于循环10次记录每次迭代的时间
k_lspia=0;
[~,k2]=size(k1); %获取插值点个数
lamda=zeros(k2,2);
 h=1;
%  e(h)=SumErrorCurve(R-B_R*P0)/(k2+1);
%  h=h+1;
A1=B_Q'*B_Q;
   miu = 2/max(sum(2*A1,2));% miu参照的是LSPIA论文选取

% eigenvalues11=eig(2*A1);
%    miu = 2/(max(eigenvalues11)+min(eigenvalues11));% miu参照的是LSPIA论文选取

%    eigenvalues1 = max(eig(2*A1)); %检验miu是否满足，以及谱半径a是否介于-1到1之间
%    miu11=2/eigenvalues1;

%    miu = 1/max(eig(2*A1));% miu参照的是LSPIA论文选取
%    miu2=2/norm(B'*B,inf);%miu=2/norm(B'*B,inf); 是改进LSPIA论文里的
     miu1=2/max(sum((B_R/B_Q)*(B_R/B_Q)'/2,2));
%    miu1=2/max(sum(B_R/(2*B_Q'*B_Q)*B_R',2));

% eigenvalues12=eig(B_R/(2*B_Q'*B_Q)*B_R');
%    miu1=2/(max(eigenvalues12)+min(eigenvalues12));

   eigenvalues2 = max(eig(B_R/(2*B_Q'*B_Q)*B_R')); %检验miu是否满足，以及谱半径a是否介于-1到1之间
   miu12=2/eigenvalues2;
%    miu1=miu12-1;
   time=0;

   e2=0;%准备计算每次LSPIA的误差
   %% 计算第一次Z值
            Z1=miu*eye(m);
            Z21=miu1*eye(k2);
            s1=2;
           %% UZAWA迭代
           % 计算第0次迭代的误差
               P=P0;
        C1=B_R*P;delta=R-C1;
       e0=SumErrorCurve_CLSPIA(delta);%LSPIA文献误差，插值误差
      C3=B_Q*P;delta3=Q-C3;
       e3(h)=SumErrorCurve_CLSPIA(delta3); %待逼近点误差
if l==0
%         C2=B*P;delta2=K-C2;
%           e(h)=SumErrorCurve_CLSPIA(delta)/(k2+1);%LSPIA文献误差，平均误差
%        e1(h)=SumErrorCurve_CLSPIA(delta2);%LSPIA文献误差，数据点误差
e(h)=e0;
       k=0;
else    
tic

for k=1:l
    t1=clock;
%     [P,s]=CLSPIACurve_LSPIA(B,B_R,B_Q,P0,Q,k1,tol,miu,lamda,s,tol1); %普通CLSPIA算法
% [P,s,e2]=CLSPIACurve_LSPIA1(B,B_R,B_Q,P0,Q,k1,tol,miu,lamda,s,tol1,e2,R); %普通CLSPIA算法
%  [P,s]=CLSPIACurve_Improve_LSPIA(B,B_R,B_Q,P0,Q,k1,tol,miu,lamda,s,tol1); %改进CLSPIA算法
%  [P,s,Z]=CLSPIACurve_Improve_LSPIA1(B,B_R,B_Q,P0,Q,k1,miu,lamda,s,m,Z,tol1); %改进CLSPIA算法，在此基础上存储Z值，避免重复计算
 [P,s,Z1,e2]=CLSPIACurve_Improve_LSPIA2(B_R,B_Q,P0,Q,lamda,s,m,Z1,tol1,R,A1,s1,e2); %改进CLSPIA算法，在此基础上存储Z值，避免重复计算
% [P,s]=CG_CLSPIACurve_LSPIA(B,B_R,B_Q,P0,Q,k1,tol,miu,lamda,s,tol1); %普通CLSPIA算法
% [P,s,e2]=CG_CLSPIACurve_LSPIA1(B_R,B_Q,P0,Q,lamda,s,tol1,e2,R,miu); %普通CLSPIA算法
 k_lspia(k)=s-sum(k_lspia);
 t2=clock;time=time+etime(t2,t1);
    P0=P;
    C1=B_R*P;delta=R-C1;
%     C2=B*P;delta2=K-C2;
      C3=B_Q*P;delta3=Q-C3;
%           e(h)=SumErrorCurve_CLSPIA(delta)/(k2+1);%LSPIA文献误差，平均误差
       e(h)=SumErrorCurve_CLSPIA(delta);%LSPIA文献误差，插值误差
       e3(h)=SumErrorCurve_CLSPIA(delta3); %待逼近点误差
%        e1(h)=SumErrorCurve_CLSPIA(delta2);%LSPIA文献误差，数据点误差
       lamda=lamda+Z21*(C1-R);
       Z22=CLSPIACurve_Improve_LSPIA_Z(k2,s1,Z21,B_R/(2*B_Q'*B_Q)*B_R');
       Z21=Z22;
       %终止条件
        err=e(end);
       if e(end)<=tol
%            e=e/e(1); % 归一化
          break
       end
              h=h+1;
%               fprintf('e2=%e',e2(end));
end
% shijian=toc;
toc
end
fprintf('e=%.4e',e(end));
% fprintf('e1=%e',e1(end));
fprintf('e3=%.4e',e3(end)); %待逼近点误差
% fprintf('LSPIA部分的迭代时间是:%f',time);
end