function [e,k,s,k_lspia,P,time]=CLSPIA_surface(B,B_R,B_Q,K,P0,Q,R,l,k1,tol) %Q是待逼近点，R是待插值点
s=0; %开始记录LSPIA迭代次数
k_lspia=0;
[~,k2]=size(k1); %获取插值点个数
lamda=zeros(k2,2);
 h=1;
%  e(h)=SumErrorCurve(R-B_R*P0)/(k2+1);
%  h=h+1;
   miu = 2/max(sum(B_Q'*B_Q,2));% miu参照的是LSPIA论文选取
%    miu2=2/norm(B'*B,inf);%miu=2/norm(B'*B,inf); 是改进LSPIA论文里的
   miu1=2/max(sum((B_R/B_Q)*(B_R/B_Q)',2));
   time=0;
   %% 计算第一次Z值
           if s==0
            Z(:,:,s+1)=miu*B_Q';
                [m,~]=size(Z);
           end
tic
for k=1:l
    t1=clock;
%     [P,s]=CLSPIACurve_LSPIA(B,B_R,B_Q,P0,Q,k1,tol,miu,lamda,s); %普通CLSPIA算法
%  [P,s]=CLSPIACurve_Improve_LSPIA(B,B_R,B_Q,P0,Q,k1,tol,miu,lamda,s); %改进CLSPIA算法
 [P,s,Z]=CLSPIACurve_Improve_LSPIA1(B,B_R,B_Q,P0,Q,k1,tol,miu,lamda,s,m,Z); %改进CLSPIA算法，在此基础上存储Z值，避免重复计算
 k_lspia(k)=s-sum(k_lspia);
 t2=clock;time=time+etime(t2,t1);
    P0=P;
    C1=B_R*P;C2=B*P;
       delta=R-C1;delta2=K-C2;
%           e(h)=SumErrorCurve(delta)/(k2+1);%LSPIA文献误差，平均误差
       e(h)=SumErrorCurve(delta);%LSPIA文献误差，插值误差
       e1(h)=SumErrorCurve(delta2);%LSPIA文献误差，数据点误差
       lamda=lamda+(C1-R)*miu1;
       %终止条件
    if h>=2
       if norm((e(h-1)-e(h)))<=tol
%            e=e/e(1); % 归一化
          break
       end
    end
              h=h+1;
end
fprintf('e=%e',e(end));
fprintf('e1=%e',e1(end));
fprintf('LSPIA部分的迭代时间是:%f',time);
toc
end