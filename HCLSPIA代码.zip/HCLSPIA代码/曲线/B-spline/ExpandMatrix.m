function B1=ExpandMatrix(m,k,T1,NodeVector1)%m为控制顶点个数,扩充配置矩阵
B1=BaseFunction(m+1,k,T1,NodeVector1);
B1=B1';
B1(2,1) = 0; B1(2,2) = 1;
B1(end-1,end-1) = 1; B1(end-1,end) = 0;
end