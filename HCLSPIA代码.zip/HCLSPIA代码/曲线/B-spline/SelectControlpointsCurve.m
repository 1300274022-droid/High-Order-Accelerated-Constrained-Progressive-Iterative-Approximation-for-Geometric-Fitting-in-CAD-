%数据点m+1个，控制点n+1个
function P=SelectControlpointsCurve(Q,m,n)
P(1,:)=Q(1,:);
P(n+1,:)=Q(m+1,:);
for i = 1:n
    P(i+1,:) = Q(floor((m+1)/n*i),:);
end
end