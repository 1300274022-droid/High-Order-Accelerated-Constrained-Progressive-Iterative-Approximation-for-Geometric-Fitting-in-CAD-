function r=CGPIA_weight1(d1,d2,k,dimension)
if k==0
    r=zeros(1,dimension);
else
d1_d1=d1*d1';
d2_d2=d2*d2';
for i=1:dimension
r(i)=d1_d1(i,i)/d2_d2(i,i);
end
end
end