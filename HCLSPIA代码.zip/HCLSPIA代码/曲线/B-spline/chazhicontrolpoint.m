function P1=chazhicontrolpoint(n,p,dimension)
P1=zeros(n+2,dimension);
for i=1:n
    P1(i+1,:)=p(i,:);
end
P1(1,:)=P1(2,:);
P1(n+2,:)=P1(n+1,:);
end