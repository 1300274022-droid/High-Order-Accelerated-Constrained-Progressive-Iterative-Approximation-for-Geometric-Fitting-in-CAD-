function [e,k,P,C]=LSPIACurve(B,P0,Q,l,tol)
   miu = 2/max(sum(B'*B,2));% miu=2/norm(B'*B,inf);
tic
for k=0:l
    C=B*P0;
    delta=Q-C;
%    e(k+1)=SumErrorCurve(delta);%LSPIA文献误差
    e(k+1)=MaxError(delta);%CGLSPIA文献误差
d=miu*B'*delta;
P=P0+d;

% P(1,:)=Q(1,:);%算CG先注释
% P(end,:)=Q(end,:);%LSPIA的有小的影响,文献4的有几个小数点不一样（加上后）

P0=P;
%终止条件？
    if k>=2
%        if norm((e(k-1)-e(k)))<=tol
       if norm((e(k-1)-e(k))/e(1))<=tol
          break
       end
    end
end
toc
fprintf('e=%e',e(end));
end