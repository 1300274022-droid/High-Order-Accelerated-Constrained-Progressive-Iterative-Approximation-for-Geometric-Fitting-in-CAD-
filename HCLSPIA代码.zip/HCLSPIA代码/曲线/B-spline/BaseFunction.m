function Nik=BaseFunction(m,k,t,node) %m为参数个数-1
    n=length(t)-1;
    Nik=zeros(m+1,n+1);
    for j=0:n
        u=t(j+1);
        for i=0:m
            Nik(i+1,j+1)=BsplineBaseFunction(i,k,u,node);
        end
    end
    b=sum(abs(Nik),1)==0;
    Nik(end,b)=1;
end