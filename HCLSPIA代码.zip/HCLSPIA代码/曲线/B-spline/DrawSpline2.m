function DrawSpline2(R, q,P1,Nik)%q是初始顶点，P1是迭代扩充后的顶点，n为控制顶点个数

xlabel('$\alpha$', 'Interpreter', 'latex'); % 正确
%% 绘画CLSPIA的插值点和逼近点
plot(R(:,1), R(:,2),...
                    'o','LineWidth',1,...
                    'MarkerEdgeColor','r',...
                    'MarkerFaceColor','r',...
                    'MarkerSize',4.5);
axis equal
% line(q(:,1), q(:,2),'Color',[0 0 0]);
hold on
plot(q(:,1), q(:,2),...
                    'o','LineWidth',1,...
                    'MarkerEdgeColor','b',...
                    'MarkerFaceColor','b',...
                    'MarkerSize',1.5);

%% 绘画LSPIA和CGLSPIA的控制顶点和数据点
% plot(q(:,1), q(:,2),'r.','MarkerSize',5);
% hold on
% plot(P(:,1), P(:,2),'b.','MarkerSize',5);

% P1=[P1;P1(1,:)];

S=Nik*P1;
% S=[S;S(1,:)];
plot(S(:,1),S(:,2),'r','LineWidth',1);
hold on
axis equal

%取当前坐标轴
ax = gca;

% 设置坐标范围
% ax.XLim = [0 1];
% ax.YLim = [-0.4 0.4];
ax.TickLength = [0.02, 0.02];

% 仅处理纵坐标负号（横坐标无负号不需要处理）
if ~isempty(ax.YTickLabel)
    ax.YTickLabel = strrep(ax.YTickLabel, '-', char(8722));
end
if ~isempty(ax.XTickLabel)
    ax.XTickLabel = strrep(ax.XTickLabel, '-', char(8722));
end

% 设置显示精度（保持小数点后1位）
% ax.YTick = 0:0.2:1;
% ax.YTickLabel = compose('%.1f', ax.YTick);  % 强制显示1位小数
ax.YTickLabel = strrep(ax.YTickLabel, '-', char(8722));
ax.XTickLabel = strrep(ax.XTickLabel, '-', char(8722));

% zp=BaseZoom();
% zp.plot;
%% 去掉坐标轴
% set(gca,'visible','off');
%% 绘制局部放大图
% axes('Position',[0.2,0.5,0.3,0.3]);   % 小图 设置小图的大小和位置（左上角位置+宽高）
% plot(R(:,1), R(:,2),...
%                     'o','LineWidth',1,...
%                     'MarkerEdgeColor','r',...
%                     'MarkerFaceColor','r',...
%                     'MarkerSize',2);
% axis equal
% % line(q(:,1), q(:,2),'Color',[1 1 1]);
% hold on
% plot(q(:,1), q(:,2),...
%                     'o','LineWidth',1,...
%                     'MarkerEdgeColor','b',...
%                     'MarkerFaceColor','b',...
%                     'MarkerSize',2);
% plot(S(:,1),S(:,2),'r','LineWidth',1);
% axis equal
% % xlim([0.64,0.95]); %设置放大图坐标范围，G577
% % xlim([0,0.2]); ylim([-0.1,0.1]); %设置放大图坐标范围，airfoil205
% xlim([-0.9,-0.5]); ylim([0.5,0.9]); %设置放大图坐标范围，冰墩墩326
% % xlim([35,62]); ylim([-2,20]); %设置放大图坐标范围，Dolphin332
% % xlim([0.4,0.56]); ylim([0.6,0.75]); %设置放大图坐标范围，rabbit-539
% 
% %% 对负号进行设定为symbol
% % 获取当前坐标轴
% ax = gca;
% 
% % 设置坐标范围
% % ax.XLim = [0 1];
% % ax.YLim = [-0.4 0.4];
% ax.TickLength = [0.02, 0.02];
% 
% % 仅处理纵坐标负号（横坐标无负号不需要处理）
% if ~isempty(ax.YTickLabel)
%     ax.YTickLabel = strrep(ax.YTickLabel, '-', char(8722));
% end
% if ~isempty(ax.XTickLabel)
%     ax.XTickLabel = strrep(ax.XTickLabel, '-', char(8722));
% end
% 
% % 设置显示精度（保持小数点后1位）
% % ax.YTick = -0.4:0.1:0.4;
% % ax.YTickLabel = compose('%.1f', ax.YTick);  % 强制显示1位小数
% ax.YTickLabel = strrep(ax.YTickLabel, '-', char(8722));
% ax.XTickLabel = strrep(ax.XTickLabel, '-', char(8722));
%% 绘画局部放大部分的矩阵方框
%确定框的位置和大小
% rectX = [0.64, 0.95]; % x坐标范围
% rectY = [0.38, 0.62]; % y坐标范围 %设置放大图坐标范围，G577
% rectX=[0,0.2]; rectY=[-0.1,0.1]; %设置放大图坐标范围，airfoil205
% rectX=[-0.9,-0.5]; rectY=[0.5,0.9]; %设置放大图坐标范围，冰墩墩326
% rectX=[35,62]; rectY=[-2,20]; %设置放大图坐标范围，Dolphin332
% rectX=[0.4,0.56]; rectY=[0.6,0.75];%设置放大图坐标范围，rabbit-539
% 在特定位置加框
% rectangle('Position',[rectX(1), rectY(1), rectX(2)-rectX(1), rectY(2)-rectY(1)], ...
% 'EdgeColor','k','LineWidth',0.5);
end