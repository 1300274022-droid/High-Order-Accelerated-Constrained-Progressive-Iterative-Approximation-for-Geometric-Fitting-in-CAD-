function [P,k]=CLSPIACurve_LSPIA(B,B_R,B_Q,P0,Q,k1,tol,miu,lamda,k,tol1) %CLSPIA里LSPIA迭代部分
    sigma1=B_R'*lamda;
while 1
        C=B*P0;
        C_Q=removerows(C,k1);
    delta1=Q-C_Q;
    epsion1=B_Q'*delta1;
    d=miu*(epsion1-sigma1);
P=P0+d;
P0=P;
k=k+1;
   if norm(d)<tol1
return
   end

end

end