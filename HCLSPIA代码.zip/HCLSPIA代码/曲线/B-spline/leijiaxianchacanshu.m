function t=leijiaxianchacanshu(m,Q) %m是数据点数-1
dd = zeros();
for i = 1:m
    dd(i) = norm(Q(i,:)-Q(i+1,:));
end
L=sum(dd);
for i = 1:m
    t(i+1) = sum(dd(1:i))/L;
end
end