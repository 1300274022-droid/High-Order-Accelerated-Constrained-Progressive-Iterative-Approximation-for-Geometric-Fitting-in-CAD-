function LPIA_Bspline_surface(m,n,k,l,Px,Py,Pz,adjust_x,adjust_y)
figure();
plot3(Px,Py,Pz,'r','linewidth',2);
hold on
plot3(Px',Py',Pz','r','linewidth',2);
hold on
plot3(Px,Py,Pz,'g.','markersize',20,'linewidth',2);
hold on
T1=chazhijiediansurface_leijia(m-1,n-1,Px,Py,Pz,1);
T2=chazhijiediansurface_leijia(m-1,n-1,Px,Py,Pz,2);
NodeVector1=[0 0 0 T1 1 1 1];NodeVector2=[0 0 0 T2 1 1 1];
T1=[0 T1 1]; T2=[0 T2 1];
%% 初始化控制顶点
Px1=chazhicontrolpointsurface(m,n,Px);
Py1=chazhicontrolpointsurface(m,n,Py);
Pz1=chazhicontrolpointsurface(m,n,Pz);
P(:,1)=reshape(Px1',[],1);P(:,2)=reshape(Py1',[],1);P(:,3)=reshape(Pz1',[],1);
Q=P;
%% 确定配置矩阵
Nik=BaseFunction(m+1,k,T1,NodeVector1);
h1=Nik(1,2);h2=Nik(2,2);Nik(2,2)=h1;Nik(1,2)=h2;h3=Nik(m+2,n+1);h4=Nik(m+1,n+1);Nik(m+1,n+1)=h3;Nik(m+2,n+1)=h4;
Nik_1=BaseFunction(n+1,k,T2,NodeVector2);
h1=Nik_1(1,2);h2=Nik_1(2,2);Nik_1(2,2)=h1;Nik_1(1,2)=h2;h3=Nik_1(m+2,n+1);h4=Nik_1(m+1,n+1);Nik_1(m+1,n+1)=h3;Nik_1(m+2,n+1)=h4;
%% 进行PIA
A=kron(Nik,Nik_1);
 for q=0:l
    P0=A*P;
    E=zeros(n+1,3);
    E(adjust,:)=q(adjust,:)-P0(adjust,:);
    e(j+1)=SumError(E);
    P=P+E;
 end
%% 输出拟合误差e
e=MaxError(E);
   fprintf('e=%e',e);
%% 绘画图像
% for i=1:m+1
%     for j=1:n+1
%         X(i,j)=P(j+(i-1)*(n+1),1);
%         Y(i,j)=P(j+(i-1)*(n+1),2);
%         Z(i,j)=P(j+(i-1)*(n+1),3);
%     end
% end
% k1=3;l1=3;
% DrawSplinesurface(m,n,k1,l1,X,Y,Z)
end