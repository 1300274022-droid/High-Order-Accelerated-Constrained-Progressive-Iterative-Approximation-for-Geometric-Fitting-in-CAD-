function DrawSpline3(P, q,P1,Nik,dimension)%q是初始顶点，P1是迭代扩充后的顶点，n为控制顶点个数
%% 绘画LSPIA和CGLSPIA的控制顶点和数据点
if dimension==2
plot(q(:,1), q(:,2),...
                    'o','LineWidth',1,...
                    'MarkerEdgeColor','b',...
                    'MarkerFaceColor','b',...
                    'MarkerSize',1.5);
hold on
% plot(P(:,1), P(:,2),'b.','MarkerSize',5);

S=Nik*P1;
S(1,:)=q(1,:);S(end,:)=q(end,:);
% S=[q(1,:);S;q(end,:)];
plot(S(:,1),S(:,2),'r','LineWidth',1);
% line(S(:, 1), S(:, 2));
hold on
axis equal
end

if dimension==3
plot3(q(:,1), q(:,2),q(:,3),'r.','MarkerSize',1.5);
hold on
plot3(P(:,1), P(:,2),P(:,3),'b.','MarkerSize',1.5);

S=Nik*P1;
plot3(S(:,1),S(:,2),S(:,3),'k','LineWidth',1);
hold on
axis equal
end
%% 绘制局部放大图
% axes('Position',[0.2,0.5,0.3,0.3]);   % 小图 设置小图的大小和位置（左上角位置+宽高）
% plot(S(:,1),S(:,2),'r','LineWidth',1);
% axis equal
% xlim([1,1.2]); %设置放大图坐标范围
%% 去掉坐标轴
set(gca,'visible','off');
end