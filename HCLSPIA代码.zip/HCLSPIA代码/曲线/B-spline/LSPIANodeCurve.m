% AlphaNodeCurve，LSPIA文献里的节点
function NodeVector=LSPIANodeCurve(t,m,n) % m,n为控制顶点数-1 
NodeVector=zeros(1,n-3);
d=(m+2)/(n-1);
for j=1:n-3
    i=floor(j*d);
    alpha=j*d-i;
    NodeVector(j)=(1-alpha)*t(i-1)+alpha*t(i);
end
NodeVector=[0,0,0,0,NodeVector,1,1,1,1];
end