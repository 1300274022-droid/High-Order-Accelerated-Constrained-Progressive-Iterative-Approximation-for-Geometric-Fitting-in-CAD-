%LSPIA文献里的，delta平方
function e=SumErrorCurve_CLSPIA(delta)%LSPIA文献误差
e = sum((sqrt(sum((delta).^2, 2))).^2);
end