function NodeVector=chazhijiediansurface1_v(n,m,px,py,pz)
NodeVector=zeros(1,n+6);
for j=0:3
    NodeVector(j+1)=0;
end
for j=4:n+2
    q=(0);
    for i=1:m
        qx=px(i,j-2)-px(i,j-3);
        qy=py(i,j-2)-py(i,j-3);
        qz=pz(i,j-2)-pz(i,j-3);
        q(i)=sqrt(qx^2+qy^2+qz^2);
    end
    q1=sum(q);
    NodeVector(j+1)=NodeVector(j)+q1/m;
end
for j=n+3:n+5
    NodeVector(j+1)=NodeVector(n+3);
end
end