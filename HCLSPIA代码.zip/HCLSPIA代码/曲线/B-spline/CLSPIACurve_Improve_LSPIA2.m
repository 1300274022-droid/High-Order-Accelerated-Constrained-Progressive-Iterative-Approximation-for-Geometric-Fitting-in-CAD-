function [P,k,Z,e]=CLSPIACurve_Improve_LSPIA2(B_R,B_Q,P0,Q,lamda,k,m,Z,tol1,R,A1,s,e) %CLSPIA里LSPIA迭代部分
% 对该算法进行改进，存储了Z值，避免了重复运算
   
sigma1=B_R'*lamda;
%     s=2;
    %% 完成第一次LSPIA循环迭代，存储Z值
        if k==0
C1=B_R*P0;delta=R-C1;
e(k+1)=SumErrorCurve_CLSPIA(delta);%LSPIA文献误差，插值误差
while 1
C_Q=B_Q*P0;
    delta1=Q-C_Q;
    epsion1=B_Q'*delta1;
    d=Z(:,:,k+1)*(2*epsion1-sigma1);
P=P0+d;
C1=B_R*P;delta=R-C1;
k=k+1;
e(k+1)=SumErrorCurve_CLSPIA(delta);%LSPIA文献误差，插值误差
P0=P;
Z(:,:,k+1)=CLSPIACurve_Improve_LSPIA_Z(m,s,Z(:,:,k),2*A1);
% e2=sqrt(sum(power(d(:), 2)));
   if sqrt(sum(power(d(:), 2)))<tol1
return
   end

end

        end
                [~,~,k3]=size(Z);
        %% 进行第二轮以上的LSPIA迭代
%     if k2>k3
%         Z(:,:,k2)=CLSPIACurve_Improve_LSPIA_Z(m,s,Z(:,:,k2-1),B_Q);
%     end
        if k>0
            k2=1; %记录该使用Z(k2)
while 1
C_Q=B_Q*P0;
    delta1=Q-C_Q;
    epsion1=B_Q'*delta1;
        if k2>k3
        Z(:,:,k2)=CLSPIACurve_Improve_LSPIA_Z(m,s,Z(:,:,k2-1),2*A1);
        end
    d=Z(:,:,k2)*(2*epsion1-sigma1);
P=P0+d;
C1=B_R*P;delta=R-C1;
k=k+1;
e(k+1)=SumErrorCurve_CLSPIA(delta);%LSPIA文献误差，插值误差
P0=P;
k2=k2+1;
e33=sqrt(sum(power(d(:), 2)));
   if sqrt(sum(power(d(:), 2)))<tol1
return
   end

end

        end
end