function step1=chazhicontrolpointsurface1(m,n,step)%迭代后的扩充控制顶点边界取最初控制顶点的值
        step1(1,1,1:3)=0;step1(1,n+2,:)=0;step1(m+2,1,:)=0;step1(m+2,n+2,:)=0;
        step1(2:m+1,1,:)=step(1:m,1,:);step1(2:m+1,n+2,:)=step(1:m,n,:);
        step1(1,2:n+1,:)=step(1,1:n,:);step1(m+2,2:n+1,:)=step(m,1:n,:);
    step1(2:m+1,2:n+1,:)=step;
end