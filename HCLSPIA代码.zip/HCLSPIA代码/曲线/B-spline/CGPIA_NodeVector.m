function NodeVector=CGPIA_NodeVector(n,t) %n为选取初始控制顶点个数
NodeVector=zeros(1,n+4);
for i=1:n-4
NodeVector(i+4)=sum(t(i+1:i+3))/3;
end
for i=n+1:n+4
    NodeVector(i)=1;
end
