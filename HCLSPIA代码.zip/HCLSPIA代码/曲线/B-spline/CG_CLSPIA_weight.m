function s=CG_CLSPIA_weight(d,v,g,dimension)
d_d=d'*d;
v_g=v'*g;
for i=1:dimension
s(i)=d_d(i,i)/v_g(i,i);
end
end