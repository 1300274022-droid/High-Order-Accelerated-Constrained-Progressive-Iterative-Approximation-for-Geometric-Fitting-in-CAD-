function e=SumError(E)
[row,column]=size(E);
for i=1:row
    d=E(i,:);
    e0(i)=norm(d,2);
end
e=sum(e0);
end