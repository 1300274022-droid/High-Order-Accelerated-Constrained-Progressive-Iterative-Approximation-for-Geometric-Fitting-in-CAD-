function DrawSpline_cube1(n, k, P,P1, NodeVector)
plot3(P1(1, :), P1(2, :),P1(3,:),...
                    'o','LineWidth',1,...
                    'MarkerEdgeColor','k',...
                    'MarkerFaceColor','g',...
                    'MarkerSize',6);
hold on
axis equal
 plot3(P1(1, :), P1(2, :),P1(3,:),'Color',[0 0 0]);
hold on
Nik1 = zeros(n+1, 1);
h=0.001;
 for u = NodeVector(k+1) :h: NodeVector(n+2)-0.000001
     if u>NodeVector(k+1)
         p_u1=p_u;
     end
    for i = 0:n
        Nik1(i+1, 1) = BsplineBaseFunction(i, k , u, NodeVector);
    end
    p_u = P * Nik1;
    if u==NodeVector(k+1)
        p_u1=p_u;
    end
     line([p_u1(1,1),p_u(1,1)], [p_u1(2,1),p_u(2,1)],[p_u1(3,1),p_u(3,1)], 'Color',[1 0 0]);
 end
end