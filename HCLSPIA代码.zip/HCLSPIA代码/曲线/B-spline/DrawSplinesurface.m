function DrawSplinesurface(m,n,k,l,P,Q)%m,n是控制点行列数-1
plot3(Q(:,:,1),Q(:,:,2),Q(:,:,3),'.r',MarkerSize=5);
hold on
% plot3(Q(:,:,1),Q(:,:,2),Q(:,:,3),'.b');
% hold on
plot3(P(:,:,1),P(:,:,2),P(:,:,3),'.b',MarkerSize=5);
hold on
U=0:0.01:1;
V=0:0.01:1;
%选择u,v方向的节点矢量
% knoutU=KTP(m,k,U);
% knoutV=KTP(n,l,V);
knoutU=chazhijiedian2(m);
knoutV=chazhijiedian2(n);
U(end)=U(end)-0.000001;
V(end)=V(end)-0.000001;
Nik_u=spcol(knoutU,k+1,U);Nik_v=spcol(knoutV,l+1,V);
S(:,:,1)=Nik_u*P(:,:,1)*Nik_v';
S(:,:,2)=Nik_u*P(:,:,2)*Nik_v';
S(:,:,3)=Nik_u*P(:,:,3)*Nik_v';

surf(S(:,:,1),S(:,:,2),S(:,:,3));
% mesh(S(:,:,1),S(:,:,2),S(:,:,3));
 shading flat
light('position',[-0.5,-0.5,0.6],'style','infinite','color','w')  %灯光
light('position',[0.5,0.5,0.6],'style','infinite','color','w')
colormap([0,0.8,0.8]);
view(-17.35,33.84);

% view(-96.54, -77.4);% bb
% brighten(0)
%  axis equal%横纵坐标等刻度
%plot3(PX,PY,PZ,'g.')
%plot3(PX,PY,PZ);
%plot3(PX',PY',PZ');
end