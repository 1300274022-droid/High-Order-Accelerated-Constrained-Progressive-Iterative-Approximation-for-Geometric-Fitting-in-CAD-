function [B,T,NodeVector]=peizhi_Matrix(n,k) %参考1论文。n为控制顶点个数，k为样条次数。扩充的配置矩阵
% NodeVector=chazhijiedian(n,p,dimension);
NodeVector=chazhijiedian1(n-1);%节点矢量
T=(0);
T(1:n)=NodeVector(4:n+3);
B=spcol(NodeVector, k+1, T);%配置矩阵
end