function [e,P,j]=CGLSPIA1(l,Q,P,dimension,Nik,tol)%没有扩充配置矩阵,m是数据点个数，n是控制点个数
P1=Nik*P;
delta=Q-P1;
e(1)=MaxError(delta);
d1=Nik'*delta;
v1=d1;
C=Nik*v1;
g=Nik'*C;
s=CG_CLSPIA_weight(d1,v1,g,dimension);
P=P+v1*diag([s(:)]); %得到迭代后的所选取部分的控制顶点

tic
    for j=1:l
P1=Nik*P;
delta=Q-P1;
e(j+1)=MaxError(delta);
d2=d1;
d1=Nik'*delta;
r=CG_CLSPIA_weight1(d1,d2,j,dimension);
v1=d1+v1*diag([r(:)]);
C=Nik*v1;
g=Nik'*C;
s=CG_CLSPIA_weight(d1,v1,g,dimension);
P=P+v1*diag([s(:)]); %得到迭代后的所选取部分的控制顶点
    if j>=2
       if norm((e(j-1)-e(j))/e(1))<=tol
          break
       end
    end
    end
toc
fprintf('e=%e',e(end));
    %% 绘画图像
%     DrawSpline1(m, k, Q,P1,P);
end