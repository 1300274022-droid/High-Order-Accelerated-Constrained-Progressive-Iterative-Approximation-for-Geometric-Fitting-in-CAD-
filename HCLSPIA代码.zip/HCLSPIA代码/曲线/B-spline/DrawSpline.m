function DrawSpline(n, k, q,p1,P1, NodeVector)%q是初始顶点，P1是迭代扩充后的顶点，n为控制顶点个数
%p1是插值点（CLSPIA）
P1=P1';
% plot(q(:,1), q(:,2),...
%                     'o','LineWidth',1,...
%                     'MarkerEdgeColor','k',...
%                     'MarkerFaceColor','g',...
%                     'MarkerSize',6);
% axis equal
% line(q(:,1), q(:,2),'Color',[0 0 0]);
% hold on
% plot(p1(:,1), p1(:,2),...
%                     'o','LineWidth',1,...
%                     'MarkerEdgeColor','k',...
%                     'MarkerFaceColor','r',...
%                     'MarkerSize',6);

Nik1 = zeros(n+2, 1);
 for u = NodeVector(k+1) :0.01: NodeVector(n+3)-0.1^13
     if u>NodeVector(k+1)
         p_u1=p_u;
     end
    for i = 0:n+1
        Nik1(i+1, 1) = BsplineBaseFunction(i, k , u, NodeVector);
    end
    p_u = P1 * Nik1;
        if u==NodeVector(k+1)
        p_u1=p_u;
        end
    
%点画法
%  line(p_u(1,1), p_u(2,1), 'Marker','.','LineStyle','-', 'Color',[.3 .6 .9]);

%线画法
    if u==NodeVector(k+1)
        p_u1=p_u;
    end
     line([p_u1(1,1),p_u(1,1)], [p_u1(2,1),p_u(2,1)], 'Color',[0 0 1],'LineWidth',1);
end
hold on
axis equal
end