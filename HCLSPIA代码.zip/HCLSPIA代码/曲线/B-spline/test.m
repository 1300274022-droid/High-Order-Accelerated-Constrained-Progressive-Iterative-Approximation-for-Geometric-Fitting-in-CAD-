clear;clc;close all

%% CGaPIA、LSPIA、CLSPIA 迭代法
k=3;l=1000;

% CLSPIA数据点
% p=struct2array(load('D:\matlab数据\Curvedata\G577.mat'));n=85;%LSPIA论文控制顶点取50个，CLSPIA取55个
% k1=[2,20,26,60,95,153,204,255,280,292,326,339,397,452,500,563];%插值点选取

% p=struct2array(load('D:\matlab数据\Curvedata\airfoil205.mat'));n=19;
% k1=[2,10,30,46,80,103,120,153,173,192,201];%插值点选取

% p=struct2array(load('D:\matlab数据\Curvedata\mouse205.mat'));n=29;
%  k1=[2,17,35,60,80,100,120,140,160,180,201];%插值点选取

% p=table2array(readtable('D:\matlab数据\Curvedata\star.txt'));n=84;
% k1=[2,37,69,105,146,149,180,221,265,308,346];

% p=table2array(readtable('D:\matlab数据\Curvedata\音乐符号305.txt'));n=54;
% k1=[2,138,165,266,305];
% p=table2array(readtable('D:\matlab数据\Curvedata\冰墩墩326.txt'));n=61;
% p=removerows(p,250);
% k1=[13,42,83,104,114,136,158,182,204,250,262,303,311];

% k11=linspace(2,164,28);k22=linspace(164,326,28);%增加插值点超过控制顶点数目.一样会导致误差减不下去
% k1=[k11,k22];
% k11=linspace(2,158,27);k22=linspace(170,326,27);%插值点数目增加到55和54都无法收敛，不能满足行满秩要求
% k1=[k11,k22];
% k11=linspace(2,152,26);k22=linspace(170,320,26);%插值点数目增加到55和54都无法收敛，不能满足行满秩要求
% k1=[k11,k22];
% p=table2array(readtable('D:\matlab数据\Curvedata\四叶草.txt','VariableNamingRule','preserve' ));n=54;
% k1=[55,165,280,390];
% p=table2array(readtable('D:\matlab数据\Curvedata\rabbit-539.txt'));n=104;
% p=removerows(p,162);
% k1=[4,24,15,67,78,162,241,278,320,362,387,436,445,492];
% k1=[4,24,15,67,78,163,241,278,320,362,387,436,445,492];
p=struct2array(load('D:\matlab数据\Curvedata\Dolphin332.mat'));n=64;
k1=[2,23,55,85,120,135,140,165,185,222,238,254,272,295,324,332];%插值点选取

% p=table2array(readtable('D:\matlab数据\Curvedata\butterfly379.txt'));n=65;
% k1=[2,51,57,106,153];%插值点选取
% p=struct2array(load('D:\matlab数据\Curvedata\circle501.mat'));n=65;
% k1=[2,51,57,106,153];%插值点选取

% x1=[0.115107,0.804762,0.563624,0.508163,0.269436];
% x=find_chazhi(p,x1);
% 根据最大曲率来取点，记得要排除第一个，否则会导致改进LSPIA算法无法使用
% k1=qulv(p(:,1)',p(:,2)');k1=k1';
% k1=removerows(k1,18);k1=k1';
% k1=sort(k1);%从小到大排序，手动挑选插值点

dimension=size(p,2);%chazhiSpline绘画曲线维数
m=length(p)-1;

p1=SelectControlpointsCurve(p,m,n); %选取控制顶点,选取个数为n+1个

T1=leijiaxianchacanshu(m,p);
for i=1:n
    T2(i+1)=T1(floor((m+1)/n*i));%从数据点参数中选取控制顶点的参数,LSPIA
end
% T2=T1(h); %自己选择的控制顶点对应的参数


% NodeVector1=LSPIANodeCurve(T1,m,n);%LSPIA进和CLSPIA节点矢量
NodeVector1=CGPIA_NodeVector(n+1,T2);%CGLSPIA节点矢量
Nik1=spcol(NodeVector1, k+1, T1);%LSPIA和CLSPIA配置矩阵


% tol=1e-12;tol1=1e-12; %尝试是否可以将H-CLSPIA的终止误差控制在和CLSPIA终止误差一个量级
tol=1e-9;tol1=1e-12;
% tol=1e-12;tol1=1e-12;
% tol=1e-13;tol1=1e-12;
% tol=1e-8;tol1=1e-8;


% 以下是CLSPIA
k2=m-length(k1)+1;%待逼近点个数

R=p(k1,:);%选取插值点 
Q=removerows(p,k1);%选取待逼近点



Nik_R=Nik1(k1,:); Nik_Q=removerows(Nik1,k1); % K和Q对应的配置矩阵


% [e1,e11,k3,s3,k_lspia,P1,time1]=CLSPIACurve(Nik1,Nik_R,Nik_Q,p,p1,Q,R,l,k1,tol,tol1);%CLSPIA

[e3,e33,k333,s333,k_lspia,P1,time3]=CLSPIACurve2(Nik1,Nik_R,Nik_Q,p,p1,Q,R,l,k1,tol,tol1,n+1);%HCLSPIA
% [e3_3,e33_3,k333_3,s333_3,k_lspia_3,P1,time3_3]=CLSPIACurve2_s3(Nik1,Nik_R,Nik_Q,p,p1,Q,R,l,k1,tol,tol1,n+1);
% [e3_4,e33_4,k333_4,s333_4,k_lspia_4,P1,time3_4]=CLSPIACurve2_s4(Nik1,Nik_R,Nik_Q,p,p1,Q,R,l,k1,tol,tol1,n+1);

%% CLSPIA曲面



%% 绘制误差图
Xscale=1;%误差横坐标间隔
Xtick=1;%横坐标间隔

% 计算e(无穷)/e(0)
% e1=e1/e1(1);e2=e2/e2(1);
% fprintf('e=%e',e1(end));
% fprintf('e=%e',e2(end));


% DrawErrorLog(m,n,k,l,Q,1e-14,Xscale,Xtick);
% e1=e1./e1(1);
% DrawErrorLog1(e1,e1,l,Xscale,Xtick);


% e11=e11(1:100);e22=e22(1:100);
% e11=e11./e11(1);e22=e22./e22(1);%归一化
% DrawErrorLog1(e11,e22,l,Xscale,Xtick);

% e11=e11./e11(1);e33=e33./e33(1);%归一化
% e11=e1/e1(1);e33=e3/e3(1);
% DrawErrorLog1(e11,e33,l,Xscale,Xtick);

%和s不同取值的三种HCLSPIA相比较
% e11=e1/e1(1);e33=e3/e3(1);e33_3=e3_3/e3_3(1);e33_4=e3_4/e3_4(1);
% DrawErrorLog2(e11,e33,e33_3,e33_4,l,Xscale,Xtick);
%% 绘制图像
Nik=Nik1;

DrawSpline2(R, Q,P1,Nik); % P1是迭代后的顶点，现在用这个
