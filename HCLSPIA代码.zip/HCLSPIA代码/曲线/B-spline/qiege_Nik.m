function Nik1=qiege_Nik(n,Nik)%将配置矩阵进行切割
         for t=2:n-1
    for j=3:n
            Nik1(t-1,j-2)=Nik(t,j);
    end
         end
end