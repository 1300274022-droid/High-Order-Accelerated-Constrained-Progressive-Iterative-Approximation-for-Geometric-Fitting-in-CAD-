function maxFlag=qulv(x0,y0)
theta = 0:0.2:2*pi;

kappa_arr = [];
posi_arr = [];
norm_arr = [];
qulv=[];
for num = 2:(length(x0)-1)
    x = x0(num-1:num+1);
    y = y0(num-1:num+1);
    [kappa,norm_l] = PJcurvature(x,y);
    %以下三个是为了绘画曲率矢量场图
%     posi_arr = [posi_arr;[x(2),y(2)]];
    kappa_arr = [kappa_arr;kappa]; %存储曲率值
%     norm_arr = [norm_arr;norm_l];
end

%% 绘制二维矢量场图
% quiver(posi_arr(:,1),posi_arr(:,2),...
%     kappa_arr.* norm_arr(:,1),kappa_arr.* norm_arr(:,2))

%% 标出曲率最大的那些点
k2=kappa_arr';
%     figure
%     plot(k2)
%     title('曲率曲线')
%     [~,maxFlag] = max(k2);%曲率最大位置
    k2=k2(~isnan(k2)); %剔除异常值nan，这是因为垂直x轴时，y导数趋近于无穷
    [~,maxFlag1]=sort(abs(k2),"descend");
%     [~,maxFlag1]=sort(k2,"ascend");
    maxFlag=maxFlag1(1:50);
    x_max = x0(maxFlag);
    y_max = y0(maxFlag);
    %% 画出图像 标注曲率最大点
%     figure
%     plot(x0,y0,'.-');
%     hold on;
%     plot(x_max,y_max,'rp')
%     title('标注最大曲率点')
%     xlabel('log10((norm(B*Xk-L)))')
%     ylabel('log10((norm(Xk)))')
end