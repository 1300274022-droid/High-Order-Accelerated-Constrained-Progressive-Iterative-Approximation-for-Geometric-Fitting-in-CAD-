function [e,k,P]=hyperpower_LSPIA(B,P0,Q,l,tol) %CLSPIA里LSPIA迭代部分
    B1=B'*B;
    B2=B1^2;
    miu3 = 2/max(sum(B2,2));% miu参照的是LSPIA论文选取
    W=miu3*B1;
    [m,n]=size(W);
    I=eye(m,n);
tic
for k=0:l
    W=W*(2*I-B1*W);
        C=B*P0;
    delta1=Q-C;
       e(k+1)=SumErrorCurve(delta1);%LSPIA文献误差
    d=W*B'*delta1;
P=P0+d;
P0=P;
%终止条件？
    if k>=2
       if norm((e(k-1)-e(k)))<=tol
          break
       end
    end

end
toc
end