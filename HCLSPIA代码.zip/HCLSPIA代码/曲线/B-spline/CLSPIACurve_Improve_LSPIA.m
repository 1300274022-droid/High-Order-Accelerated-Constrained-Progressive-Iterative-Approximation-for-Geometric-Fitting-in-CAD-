function [P,k]=CLSPIACurve_Improve_LSPIA(B,B_R,B_Q,P0,Q,k1,~,miu,lamda,k,tol1) %CLSPIA里LSPIA迭代部分

    sigma1=B_Q/(B_Q'*B_Q)*B_R'*lamda;
    Z=miu*B_Q';[m,~]=size(Z);
    s=3;
while 1
        C=B*P0;
        C_Q=removerows(C,k1);
    delta1=Q-C_Q;
%     epsion1=Z*delta1;
    d=Z*(delta1-sigma1);
P=P0+d;
P0=P;
Z=CLSPIACurve_Improve_LSPIA_Z(m,s,Z,B_Q);
k=k+1;
   if norm(d)<tol1
return
   end

end

end