function [e,P,j]=CGLSPIA(l,Q,P,dimension,Nik,tol)%没有扩充配置矩阵,m是数据点个数，n是控制点个数
n=length(P);
d1=(0);v1=zeros(dimension,n);
P1=Nik*P;
tic
    for j=0:l
delta=Q-P1;
e(j+1)=MaxError(delta);
d2=d1;
d1=delta'*Nik;
r=CGPIA_weight1(d1,d2,j,dimension);
v1=d1+diag([r(:)])*v1;
C=Nik*v1';
g=C'*Nik;
s=CGPIA_weight(d1,v1,g,dimension);
P=P+v1'*diag([s(:)]); %得到迭代后的所选取部分的控制顶点
P1=Nik*P;
    if j>=2
       if norm((e(j-1)-e(j))/e(1))<=tol
          break
       end
    end
    end
toc
fprintf('e=%e',e(end));
    %% 绘画图像
%     DrawSpline1(m, k, Q,P1,P);
end