function WPIA_Bspline(n,k,l,p,dimension)%n为控制点个数
% NodeVector=chazhijiedian(n,p,dimension);
NodeVector=chazhijiedian1(n-1);%节点矢量
q=p;
T=(0);
T(1:n)=NodeVector(4:n+3);
Nik=spcol(NodeVector, k+1, T);%配置矩阵
       for t=2:n-1
    for j=3:n
            Nik_1(t-1,j-2)=Nik(t,j);
    end
       end
w=2/(1+min(eig(Nik_1)));%确定权重
%% 进行PIA
   for j=0:l
P1=chazhicontrolpoint(n,p,dimension);
E=q-Nik*P1;
e(j+1)=MaxError(E);
p=p+w*(q-Nik*P1);
   end
P1=chazhicontrolpoint(n,p,dimension);%扩充控制顶点

   %% 输出拟合误差e
    fprintf('e=%e',e);

%绘制迭代次数与迭代误差折线图
%      x=0:l;
%      plot(x,e,'-*k');
% %      legend('PIA');
%      hold on
%% 绘制图像
% DrawSpline(n, k, q,P1, NodeVector)
DrawSpline_cube(n,k, q,P1, NodeVector)
end