function [e,P1]=LPIA_Bspline(n,k,l,p,adjust)%使用0到n+1这篇论文算法
% figure 
% plot(p(:,1),p(:,2),'b',p(adjust,1),p(adjust,2),'r*');axis equal;hold on;
q=p;

% T1=leijiaxianchacanshu(n,p,2);

%% 构建配置矩阵
   n=n+1;
   NodeVector=chazhijiedian(n,p,2);
   T1(1:n)=NodeVector(4:n+3);
   P1=chazhicontrolpoint(n,p,2);
   Nik=spcol(NodeVector, k+1, T1);%配置矩阵
%    Nik1=BaseFunction(n+1,k,T1,NodeVector); %自己写的配置矩阵
%% LPIA
   for j=0:l
    P0=Nik*P1;
    E=zeros(n,2);
    E(adjust,:)=q(adjust,:)-P0(adjust,:);
    e(j+1)=SumError(E);
    P1(2:n+1,:)=P1(2:n+1,:)+E;
    P1(1,:)=P1(2,:);
    P1(n+2,:)=P1(n+1,:);
   end
%% 计算迭代时间
% tic
% e1=sqrt(step_x1(:,l+1).^2+step_y1(:,l+1).^2);%最后一次拟合误差
%  e=sum(e1,1);
% while e>0.1^12
%     l=l+1;
%        for t=1:n
%     for i = 0:n+1 
%       Bt_x1(i+1) = P1(i+1,1)*Nik(t,i+1); 
%       Bt_y1(i+1) = P1(i+1,2)*Nik(t,i+1); 
%     end
%     Bt_x2(t,j+1) = sum(Bt_x1); 
%     Bt_y2(t,j+1) = sum(Bt_y1);  
%        end
%        for i=1:length_adjust
%          h_1=adjust(i);
%     step_x(h_1,j+1)=q(h_1,1)-Bt_x2(h_1,j+1);
%     step_y(h_1,j+1)=q(h_1,2)-Bt_y2(h_1,j+1);
%     step_x1(i) = step_x(h_1,j+1);%为拟合误差计算准备
%     step_y1(i) = step_y(h_1,j+1);
%     P1(h_1+1,1)=P1(h_1+1,1)+step_x(h_1,j+1);
%     P1(h_1+1,2)=P1(h_1+1,2)+step_y(h_1,j+1);
%        end
%  e1=sqrt(step_x1.^2+step_y1.^2);%最后一次拟合误差
%  e=sum(e1,1);
%     P1(1,:)=P1(2,:);
%     P1(n+2,:)=P1(n+1,:);
%  end
% toc
% fprintf('l=%f',l);

 %% 输出拟合误差e
%     e1=sqrt(step_x1(:,l+1).^2+step_y1(:,l+1).^2);%最后一次拟合误差
%    fprintf('e=%e',e);
%% 画图 
%    P=q;P1=p';
%    DrawSpline(n-1, k, P,P1, NodeVector);
% 
% for i=1:length(adjust)
%     plot(q(adjust(i), 1), q(adjust(i), 2),...
%                     'o',...
%                     'MarkerFaceColor','r',...
%                     'MarkerSize',3.2);
%     hold on
% end

end